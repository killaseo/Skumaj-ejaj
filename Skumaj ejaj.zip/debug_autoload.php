<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

spl_autoload_register(function (string $class): void {
    $prefix = 'TextMixer\\';
    if (str_starts_with($class, $prefix)) {
        $file = __DIR__ . '/src/' . substr($class, strlen($prefix)) . '.php';
        echo "LOAD: $class => $file<br>";
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }
    throw new RuntimeException("Cannot autoload class: $class");
});

new TextMixer\ProfileManager(__DIR__ . '/profiles');
echo "OK";