<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

echo "<pre>";
echo "__DIR__: " . __DIR__ . "\n";

$candidates = [
    __DIR__ . '/../../vectors/vectors_clean.sqlite',
    __DIR__ . '/../vectors/vectors_clean.sqlite',
    __DIR__ . '/vectors/vectors_clean.sqlite',
];

foreach ($candidates as $c) {
    $r = realpath($c);
    echo "TRY: $c\n";
    echo "REALPATH: " . ($r ?: 'false') . "\n";
    echo "IS_FILE: " . (is_file($c) ? 'yes' : 'no') . "\n";
    echo "----\n";
}