<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

spl_autoload_register(function (string $class): void {
    $prefix = 'TextMixer\\';
    if (str_starts_with($class, $prefix)) {
        $file = __DIR__ . '/src/' . substr($class, strlen($prefix)) . '.php';
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }
    throw new RuntimeException("Cannot autoload class: $class");
});

echo "<pre>";

try {
    $profilesDir = __DIR__ . '/profiles';
    $vectorsPath = realpath(__DIR__ . '/../../vectors/vectors_clean.sqlite');

    $pm = new TextMixer\ProfileManager($profilesDir);
    echo "ProfileManager OK\n";

    $vi = new TextMixer\VectorIndex($vectorsPath);
    echo "VectorIndex OK\n";

    $ps = new TextMixer\ProfileSelector($pm, $vi->isAvailable() ? $vi : null);
    echo "ProfileSelector OK\n";

    $tcb = new TextMixer\TopicContextBuilder($vi->isAvailable() ? $vi : null);
    echo "TopicContextBuilder OK\n";

    $profile = $pm->load('generic');
    echo "Profile load OK\n";

    $entity = new TextMixer\EntityExtractor($profile);
    echo "EntityExtractor OK\n";

    $rel = new TextMixer\RelationMapper($profile);
    echo "RelationMapper OK\n";

    $disc = new TextMixer\DiscourseClassifier($profile);
    echo "DiscourseClassifier OK\n";

    $planner = new TextMixer\CompositionPlanner($profile);
    echo "CompositionPlanner OK\n";

    $composer = new TextMixer\Composer(new TextMixer\Deduplicator(), $profile);
    echo "Composer OK\n";

} catch (Throwable $e) {
    echo "ERROR:\n";
    echo $e->getMessage() . "\n";
    echo $e->getFile() . ":" . $e->getLine() . "\n";
}