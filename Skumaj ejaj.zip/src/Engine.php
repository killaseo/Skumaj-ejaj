<?php
declare(strict_types=1);

namespace TextMixer;

class Engine
{
    private DiscourseClassifier $discourseClassifier;
    private CompositionPlanner $compositionPlanner;

    public function __construct(
        private Ingestor $ingestor,
        private Cleaner $cleaner,
        private Segmenter $segmenter,
        private LexicalScorer $lexScorer,
        private EntityExtractor $entityExtractor,
        private AliasResolver $aliasResolver,
        private RelationMapper $relationMapper,
        private Clusterer $clusterer,
        private ConflictDetector $conflictDetector,
        private CoreExtractor $coreExtractor,
        private Composer $composer,
        private JsonWriter $writer,
        private ?ProfileSelector $profileSelector = null,
        private ?TopicContextBuilder $topicContextBuilder = null,
        private ?Profile $forcedProfile = null,
    ) {
        $this->discourseClassifier = new DiscourseClassifier();
        $this->compositionPlanner = new CompositionPlanner();
    }

    public function run(): void
    {
        $debug = [];
        $t0 = microtime(true);

        echo "[1/14] Ingesting source files...
";
        $sources = $this->ingestor->ingest();
        $debug['sources_count'] = count($sources);
        echo "       " . count($sources) . " source(s) loaded.
";

        echo "[2/14] Cleaning text...
";
        $sources = $this->cleaner->clean($sources);

        echo "[3/14] Segmenting into meaning units...
";
        $segments = $this->segmenter->segment($sources);
        $debug['segments_count'] = count($segments);
        echo "       " . count($segments) . " segment(s) produced.
";

        echo "[4/14] Running lexical analysis and scoring...
";
        $segments = $this->lexScorer->score($segments);

        $profile = $this->forcedProfile;
        if ($profile === null && $this->profileSelector !== null) {
            $profile = $this->profileSelector->select($segments);
        }
        $profile ??= new Profile(['name' => 'generic']);
        $topicContext = $this->topicContextBuilder?->build($profile, $segments)
            ?? new TopicContext('Temat', [], [], [], []);
        $debug['active_profile'] = $profile->getName();
        $debug['topic_context'] = $topicContext->asArray();
        foreach ([$this->entityExtractor,$this->relationMapper,$this->compositionPlanner,$this->composer,$this->discourseClassifier] as $obj) {
            if (method_exists($obj, 'setRuntimeContext')) {
                $obj->setRuntimeContext($profile, $topicContext);
            }
        }
        echo "       profile: " . $profile->getName() . " | topic: " . $topicContext->mainTopicPhrase . "
";

        echo "[5/14] Extracting entities...
";
        $segments = $this->entityExtractor->extract($segments);
        $entityRegistry = $this->entityExtractor->getRegistry();
        $debug['entities_raw_count'] = count($entityRegistry);
        echo "       " . count($entityRegistry) . " raw entity/ies found.
";

        echo "[6/14] Resolving entity aliases...
";
        $entityRegistry = $this->aliasResolver->resolve($entityRegistry);
        $segments = $this->aliasResolver->remapSegmentEntities($segments);
        $debug['entities_resolved_count'] = count($entityRegistry);
        $debug['entity_id_remaps'] = method_exists($this->aliasResolver, 'getResolvedEntityIdMap') ? $this->aliasResolver->getResolvedEntityIdMap() : [];
        echo "       " . count($entityRegistry) . " entity/ies after merging.
";

        echo "[7/14] Mapping relations...
";
        $segments = $this->relationMapper->map($segments);
        $relCount = array_sum(array_map(fn($s) => count($s['relations']), $segments));
        $debug['relations_count'] = $relCount;
        echo "       $relCount relation(s) detected.
";

        echo "[8/14] Clustering segments...
";
        $clusterResult = $this->clusterer->cluster($segments, $entityRegistry);
        $segments = $clusterResult['segments'];
        $clusters = $clusterResult['clusters'];
        $debug['clusters_count'] = count($clusters);
        $debug['cluster_debug'] = $clusterResult['cluster_debug'] ?? [];
        echo "       " . count($clusters) . " cluster(s) formed.
";

        echo "[9/14] Classifying discourse type...
";
        $segDiscourse = $this->discourseClassifier->classifySegments($segments);
        $segments = $segDiscourse['segments'];
        $clusterDiscourse = $this->discourseClassifier->classifyClusters($clusters, $segments);
        $clusters = $clusterDiscourse['clusters'];
        $discourseDebug = ['segments' => $segDiscourse['debug']['segments'] ?? [], 'clusters' => $clusterDiscourse['debug']['clusters'] ?? []];
        echo "       discourse annotated for segments and clusters.
";

        echo "[10/14] Detecting conflicts...
";
        $conflicts = $this->conflictDetector->detect($segments, $entityRegistry);
        $debug['conflicts_count'] = count($conflicts);
        echo "       " . count($conflicts) . " conflict(s) recorded.
";

        echo "[11/14] Extracting core facts (cross-source claim groups)...
";
        $coreData = $this->coreExtractor->extract($segments, $clusters, $entityRegistry);
        $coreDebug = $coreData['_debug'] ?? [];
        unset($coreData['_debug']);
        $debug['core_facts_count'] = count($coreData['core_facts']);
        $debug['cross_source_links'] = $coreDebug['cross_source_links'] ?? 0;
        echo "       " . count($coreData['core_facts']) . " core fact(s), " . count($coreData['secondary_facts']) . " secondary, " . count($coreData['discarded_noise']) . " noise.
";

        echo "[12/14] Building composition plan...
";
        $plan = $this->compositionPlanner->buildPlan($coreData, $clusters, $segments);
        $debug['composition_mode'] = $plan['composition_mode'] ?? 'unified_article';
        echo "       mode: " . ($plan['composition_mode'] ?? 'unified_article') . "
";

        echo "[13/14] Composing output text (with deduplication)...
";
        $finalText = $this->composer->compose($coreData, $clusters, $segments, $plan);
        $debug['deduplication'] = method_exists($this->composer, 'getDeduplicationDebug') ? $this->composer->getDeduplicationDebug() : [];
        echo "       composed.
";

        echo "[14/14] Writing output files...
";
        $this->writer->writeSegments($segments);
        $this->writer->writeEntities($entityRegistry);
        $this->writer->writeClusters($clusters);
        $this->writer->writeConflicts($conflicts);
        $this->writer->writeCore($coreData);
        $this->writer->writeDiscourse($discourseDebug);
        $this->writer->writePlan($plan);
        $this->writer->writeFinalText($finalText);
        $debug['elapsed_ms'] = round((microtime(true) - $t0) * 1000, 2);
        $this->writer->writeBuildDebug($debug);

        echo "
Done in {$debug['elapsed_ms']} ms.
";
        echo "Output written to: output/
";
    }
}
