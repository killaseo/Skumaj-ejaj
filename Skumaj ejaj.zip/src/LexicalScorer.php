<?php
declare(strict_types=1);

namespace TextMixer;

/**
 * LexicalScorer
 * Tokenises each segment, detects 2-4 word phrases, scores tokens and phrases,
 * and populates: tokens, phrases, keywords, score (lexical component).
 */
class LexicalScorer
{
    // Words to ignore completely
    private const STOPWORDS = [
        'a','an','the','and','or','but','in','on','at','to','for','of','with',
        'by','from','is','are','was','were','be','been','being','has','have',
        'had','do','does','did','not','that','this','these','those','it','its',
        'as','up','if','so','no','he','she','they','we','you','i','his','her',
        'their','our','my','your','its','into','than','then','also','which',
        'who','what','where','when','how','all','some','any','each','every',
        'both','few','more','most','other','such','about','after','before',
        'between','through','during','including','until','against','among',
        'throughout','despite','towards','upon','concerning',
    ];

    // Phrase boost words — presence in a phrase raises its score
    private const TOPIC_SEEDS = [
        'mountain','mount','sleza','sleza','massif','sacred','cult','pagan',
        'ritual','church','landscape','park','summit','altitude','meters',
        'silesia','silesian','poland','polish','medieval','century','stone',
        'sculpture','artifact','pilgrimage','sobotka','trail','hike','forest',
        'bronze','age','archaeological','inselberg','foreland','sudeten',
    ];

    /** @param array<int,array<string,mixed>> $segments */
    public function score(array $segments): array
    {
        $corpusFreq = $this->buildCorpusFrequency($segments);

        foreach ($segments as &$seg) {
            $tokens   = $this->tokenise($seg['normalized']);
            $phrases  = $this->detectPhrases($tokens);
            $keywords = $this->extractKeywords($tokens, $corpusFreq);
            $lexScore = $this->computeLexScore($tokens, $phrases, $keywords, $seg['position']);

            $seg['tokens']   = $tokens;
            $seg['phrases']  = $phrases;
            $seg['keywords'] = $keywords;
            $seg['score']    = round($lexScore, 4);
        }
        unset($seg);
        return $segments;
    }

    /** @return string[] */
    private function tokenise(string $normalized): array
    {
        $words = preg_split('/\s+/', $normalized) ?: [];
        $tokens = [];
        foreach ($words as $w) {
            $w = trim($w, ".,!?;:\"'()-");
            if ($w === '' || strlen($w) < 2) continue;
            if (in_array($w, self::STOPWORDS, true)) continue;
            $tokens[] = $w;
        }
        return array_values($tokens);
    }

    /**
     * Detect 2-4 word phrases from token list.
     * A phrase scores higher if its constituent words appear in TOPIC_SEEDS.
     * @param  string[] $tokens
     * @return array<int, array{phrase:string, score:float}>
     */
    private function detectPhrases(array $tokens): array
    {
        $phrases = [];
        $n = count($tokens);
        for ($size = 2; $size <= 4; $size++) {
            for ($i = 0; $i <= $n - $size; $i++) {
                $slice  = array_slice($tokens, $i, $size);
                $phrase = implode(' ', $slice);
                $score  = 0.0;
                foreach ($slice as $t) {
                    if (in_array($t, self::TOPIC_SEEDS, true)) $score += 1.0;
                }
                if ($score > 0) {
                    $phrases[] = ['phrase' => $phrase, 'score' => round($score / $size, 4)];
                }
            }
        }
        // Deduplicate by phrase string, keep highest score
        $best = [];
        foreach ($phrases as $p) {
            $k = $p['phrase'];
            if (!isset($best[$k]) || $p['score'] > $best[$k]['score']) {
                $best[$k] = $p;
            }
        }
        return array_values($best);
    }

    /**
     * @param  string[] $tokens
     * @param  array<string,int> $corpusFreq
     * @return array<int, array{word:string, tf:int, idf:float, weight:float}>
     */
    private function extractKeywords(array $tokens, array $corpusFreq): array
    {
        $tf = array_count_values($tokens);
        $total = count($tokens) ?: 1;
        $keywords = [];
        foreach ($tf as $word => $count) {
            $tfNorm = $count / $total;
            $df     = $corpusFreq[$word] ?? 1;
            $idf    = log(10 / $df + 1);
            $seed   = in_array($word, self::TOPIC_SEEDS, true) ? 1.5 : 1.0;
            $weight = round($tfNorm * $idf * $seed, 4);
            $keywords[] = ['word' => $word, 'tf' => $count, 'idf' => round($idf,4), 'weight' => $weight];
        }
        usort($keywords, fn($a,$b) => $b['weight'] <=> $a['weight']);
        return array_slice($keywords, 0, 15);
    }

    /** @param string[] $tokens @param array<int,array{phrase:string,score:float}> $phrases @param array<int,array{word:string,weight:float}> $keywords */
    private function computeLexScore(array $tokens, array $phrases, array $keywords, int $position): float
    {
        $wordScore   = array_sum(array_column($keywords, 'weight'));
        $phraseScore = array_sum(array_column($phrases, 'score'));
        $density     = count($tokens) > 0 ? count($keywords) / count($tokens) : 0;
        $posBoost    = $position === 0 ? 1.3 : ($position <= 2 ? 1.1 : 1.0);
        return ($wordScore * 0.5 + $phraseScore * 0.3 + $density * 0.2) * $posBoost;
    }

    /** @param array<int,array<string,mixed>> $segments @return array<string,int> */
    private function buildCorpusFrequency(array $segments): array
    {
        $freq = [];
        foreach ($segments as $seg) {
            $words = preg_split('/\s+/', $seg['normalized'] ?? '') ?: [];
            $seen  = [];
            foreach ($words as $w) {
                $w = trim($w, ".,!?;:\"'()-");
                if ($w === '' || in_array($w, self::STOPWORDS, true)) continue;
                if (!isset($seen[$w])) {
                    $freq[$w] = ($freq[$w] ?? 0) + 1;
                    $seen[$w] = true;
                }
            }
        }
        return $freq;
    }
}
