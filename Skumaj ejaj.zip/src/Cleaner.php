<?php
declare(strict_types=1);

namespace TextMixer;

/**
 * Cleaner
 * Normalises raw text: strips control characters, normalises whitespace,
 * removes repeated punctuation, standardises quotes and dashes.
 * Populates clean_text on each TextSource; raw_text is never modified.
 */
class Cleaner
{
    /**
     * @param  array<int, array<string,string>> $sources
     * @return array<int, array<string,string>>
     */
    public function clean(array $sources): array
    {
        foreach ($sources as &$source) {
            $source['clean_text'] = $this->cleanText($source['raw_text']);
        }
        unset($source);
        return $sources;
    }

    public function cleanText(string $raw): string
    {
        // Normalise line endings
        $text = str_replace(["\r\n", "\r"], "\n", $raw);

        // Remove null bytes and other control chars except \n and \t
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $text);

        // Normalise unicode dashes to ASCII hyphen
        $text = preg_replace('/[\x{2010}-\x{2015}\x{2212}]/u', '-', $text);

        // Normalise unicode quotes to ASCII
        $text = preg_replace('/[\x{2018}\x{2019}]/u', "'", $text);
        $text = preg_replace('/[\x{201C}\x{201D}]/u', '"', $text);

        // Collapse multiple spaces/tabs into one space
        $text = preg_replace('/[ \t]+/', ' ', $text);

        // Collapse 3+ consecutive newlines into 2
        $text = preg_replace('/\n{3,}/', "\n\n", $text);

        // Trim each line
        $lines = explode("\n", $text);
        $lines = array_map('trim', $lines);

        // Remove completely empty lines at start/end
        $text = implode("\n", $lines);
        $text = trim($text);

        return $text;
    }
}
