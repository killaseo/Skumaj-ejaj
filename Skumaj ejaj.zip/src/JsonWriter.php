<?php
declare(strict_types=1);

namespace TextMixer;

class JsonWriter
{
    private string $outputDir;
    private const FLAGS = JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;

    public function __construct(string $outputDir)
    {
        $this->outputDir = rtrim($outputDir, DIRECTORY_SEPARATOR);
        if (!is_dir($this->outputDir)) {
            mkdir($this->outputDir, 0755, true);
        }
    }

    /** @param array<int,array<string,mixed>> $segments */
    public function writeSegments(array $segments): void { $this->write('segments.json', $segments); }
    /** @param array<string,array<string,mixed>> $entityRegistry */
    public function writeEntities(array $entityRegistry): void { $this->write('entities.json', array_values($entityRegistry)); }
    /** @param array<int,array<string,mixed>> $clusters */
    public function writeClusters(array $clusters): void { $this->write('clusters.json', $clusters); }
    /** @param array<int,array<string,mixed>> $conflicts */
    public function writeConflicts(array $conflicts): void { $this->write('conflicts.json', $conflicts); }
    /** @param array<string,mixed> $coreData */
    public function writeCore(array $coreData): void { $this->write('core.json', $coreData); }
    /** @param array<string,mixed> $debugDump */
    public function writeBuildDebug(array $debugDump): void { $this->write('build_debug.json', $debugDump); }
    /** @param array<string,mixed> $discourse */
    public function writeDiscourse(array $discourse): void { $this->write('discourse.json', $discourse); }
    /** @param array<string,mixed> $plan */
    public function writePlan(array $plan): void { $this->write('plan.json', $plan); }

    public function writeFinalText(string $text): void
    {
        $path = $this->outputDir . DIRECTORY_SEPARATOR . 'final_test_output.txt';
        if (file_put_contents($path, $text) === false) {
            throw new \RuntimeException("Cannot write: $path");
        }
        echo "  [OK] final_test_output.txt\n";
    }

    /** @param mixed $data */
    private function write(string $filename, $data): void
    {
        $path    = $this->outputDir . DIRECTORY_SEPARATOR . $filename;
        $encoded = json_encode($data, self::FLAGS);
        if ($encoded === false) {
            throw new \RuntimeException("JSON encode failed for $filename: " . json_last_error_msg());
        }
        if (file_put_contents($path, $encoded) === false) {
            throw new \RuntimeException("Cannot write: $path");
        }
        echo "  [OK] $filename\n";
    }
}
