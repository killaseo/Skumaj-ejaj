<?php
declare(strict_types=1);

namespace TextMixer;

/**
 * Segmenter
 * Splits clean text into meaning segments.
 * Rule: 1 sentence = 1 segment by default.
 * Exception: if the next sentence is <=8 words AND starts with a
 * continuation word (e.g. "It", "This", "However", "Which", "That",
 * "These", "Those", "Its") it is merged with the previous sentence.
 *
 * ── Abbreviation handling ────────────────────────────────────────────────────
 * The naive regex  /(?<=[.!?])\s+(?=[A-Z"])/  fires on tokens like
 * "St. Stephen", "Dr. Smith", "Mr. Jones", "approx. 7,500" etc., producing
 * spurious one-word fragments that later get re-joined as "St. St." artifacts
 * in the composed output.
 *
 * Fix: before splitting, we temporarily replace the period in every known
 * abbreviation + the following space with a placeholder (\x02), run the
 * normal sentence-boundary split, then restore the placeholder.  This keeps
 * the regex simple and avoids full-blown POS tagging.
 *
 * Covered abbreviation classes:
 *   - Titles       : Mr, Mrs, Ms, Dr, Prof, Rev, Sr, Jr, St, Lt, Sgt, Cpl,
 *                    Capt, Col, Gen, Pres, Gov
 *   - Academic     : Ph.D, M.D, B.Sc, M.Sc (handled as multi-dot tokens)
 *   - Geographic   : St (Saint/Street), Mt, Ft, Ave, Blvd, Rd, approx, ca
 *   - Latin/misc   : etc, vs, cf, i.e, e.g, no (number), vol, p (page)
 *   - Single upper : any isolated capital letter (e.g. initials "J. Smith")
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * Segment shape (partial - LexicalScorer fills the rest):
 *   segment_id  : string
 *   source_id   : string
 *   position    : int     (0-based index within source)
 *   raw         : string  (original sentence(s))
 *   normalized  : string  (lowercased, punctuation stripped)
 *   tokens      : []      (filled by LexicalScorer)
 *   phrases     : []
 *   keywords    : []
 *   entities    : []
 *   relations   : []
 *   score       : float
 *   cluster_id  : string|null
 *   status      : string  ("active")
 */
class Segmenter
{
    private const CONTINUATION_WORDS = [
        'it','this','that','these','those','its','they','their',
        'he','she','which','who','however','but','also','additionally',
        'furthermore','moreover','therefore','thus','hence',
    ];

    /**
     * Known abbreviations whose trailing period must NOT trigger a sentence
     * boundary.  Listed in lowercase; matching is case-insensitive.
     * The list intentionally excludes sentential uses ("end of sentence.").
     */
    private const ABBREVIATIONS = [
        // Titles
        'mr','mrs','ms','dr','prof','rev','sr','jr','st','lt',
        'sgt','cpl','capt','col','gen','pres','gov','atty','supt',
        // Geographic / address
        'mt','ft','ave','blvd','rd','dept','est',
        // Measurement / misc
        'approx','ca','no','vol','vs','cf','fig','sec','ref',
        // Latin abbreviations (without the interior dot variant)
        'etc','ibid','viz',
        // Single capital letter — initials like "J. Smith"
        'a','b','c','d','e','f','g','h','i','j','k','l','m',
        'n','o','p','q','r','s','t','u','v','w','x','y','z',
    ];

    /** Placeholder character used to protect abbreviation periods. */
    private const PERIOD_PLACEHOLDER = "\x02";

    private int $globalCounter = 0;

    /** @return array<int, array<string,mixed>> */
    public function segment(array $sources): array
    {
        $allSegments = [];
        foreach ($sources as $source) {
            $sentences = $this->splitSentences($source['clean_text']);
            $merged    = $this->mergeShort($sentences);
            foreach ($merged as $pos => $text) {
                $allSegments[] = $this->makeSegment($text, $source['source_id'], $pos);
            }
        }
        return $allSegments;
    }

    // ── Sentence splitting ────────────────────────────────────────────────────

    /** @return string[] */
    private function splitSentences(string $text): array
    {
        // Step 1: protect abbreviation periods so they don't trigger splits.
        $text = $this->protectAbbreviations($text);

        // Step 2: also protect "e.g." and "i.e." which contain interior dots.
        // Pattern: letter DOT letter DOT  (handles i.e., e.g., p.m., a.m., etc.)
        $text = preg_replace('/\b([a-zA-Z])\.([ ]?)([a-zA-Z])\./', '$1' . self::PERIOD_PLACEHOLDER . '$2$3' . self::PERIOD_PLACEHOLDER, $text) ?? $text;

        // Step 3: split on sentence-ending punctuation followed by whitespace + capital.
        $parts = preg_split('/(?<=[.!?])\s+(?=[A-Z"])/', $text);
        $parts = $parts ?: [$text];

        // Step 4: restore placeholders in every resulting fragment.
        $parts = array_map(fn(string $p) => str_replace(self::PERIOD_PLACEHOLDER, '.', $p), $parts);

        return array_values(array_filter(array_map('trim', $parts)));
    }

    /**
     * Replace the period (and trailing space) of every known abbreviation
     * token with PERIOD_PLACEHOLDER so the sentence splitter ignores them.
     *
     * Regex: \b(abbrev)\.(?=\s) — word-boundary + abbreviation + period + space-ahead.
     * Case-insensitive flag covers "Mr.", "mr.", "MR." etc.
     */
    private function protectAbbreviations(string $text): string
    {
        // Build alternation from the abbreviation list once.
        $alts = implode('|', array_map('preg_quote', self::ABBREVIATIONS));

        // Match: word boundary, one of the abbreviations, a literal dot,
        // lookahead for whitespace (the dot is at end of token, not sentence).
        $pattern = '/\b(' . $alts . ')\.(?=\s)/i';

        return preg_replace($pattern, '$1' . self::PERIOD_PLACEHOLDER, $text) ?? $text;
    }

    // ── Short-sentence merging ────────────────────────────────────────────────

    /** @param string[] $sentences @return string[] */
    private function mergeShort(array $sentences): array
    {
        $result = [];
        $i = 0;
        while ($i < count($sentences)) {
            $current = $sentences[$i];
            if (isset($sentences[$i + 1])) {
                $next      = $sentences[$i + 1];
                $nextWords = str_word_count($next);
                $firstWord = strtolower(strtok($next, " \t\n"));
                if ($nextWords <= 8 && in_array($firstWord, self::CONTINUATION_WORDS, true)) {
                    $current .= ' ' . $next;
                    $i++;
                }
            }
            $result[] = $current;
            $i++;
        }
        return $result;
    }

    // ── Segment factory ───────────────────────────────────────────────────────

    /** @return array<string,mixed> */
    private function makeSegment(string $raw, string $sourceId, int $position): array
    {
        $this->globalCounter++;
        $normalized = strtolower(preg_replace('/[^\w\s]/u', ' ', $raw) ?? $raw);
        $normalized = preg_replace('/\s+/', ' ', trim($normalized)) ?? $normalized;

        return [
            'segment_id' => sprintf('seg_%04d', $this->globalCounter),
            'source_id'  => $sourceId,
            'position'   => $position,
            'raw'        => $raw,
            'normalized' => $normalized,
            'tokens'     => [],
            'phrases'    => [],
            'keywords'   => [],
            'entities'   => [],
            'relations'  => [],
            'score'      => 0.0,
            'cluster_id' => null,
            'status'     => 'active',
        ];
    }
}
