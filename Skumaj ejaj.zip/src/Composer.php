<?php
declare(strict_types=1);

namespace TextMixer;

class Composer
{
    private array $deduplicationDebug = [];
    private ?Profile $profile = null;
    private ?TopicContext $topicContext = null;

    public function setRuntimeContext(Profile $profile, TopicContext $topicContext): void
    {
        $this->profile = $profile;
        $this->topicContext = $topicContext;
    }

    /** @param array<string,mixed> $coreData @param array<int,array<string,mixed>> $clusters @param array<int,array<string,mixed>> $segments @param array<string,mixed>|null $plan */
    public function compose(array $coreData, array $clusters, array $segments, ?array $plan = null): string
    {
        $dedup = new Deduplicator(0.76);
        $dedupResult = $dedup->deduplicate($segments);
        $this->deduplicationDebug = ['kept_count' => count($dedupResult['kept']), 'rejected_count' => count($dedupResult['rejected'])];
        $clusterIndex = [];
        foreach ($clusters as $cluster) $clusterIndex[(string)$cluster['cluster_id']] = $cluster;
        $topic = (string)($plan['main_topic_entity'] ?? $this->topicContext?->mainTopicPhrase ?? $coreData['topic_entity'] ?? 'Temat');
        $paragraphs = [];
        $used = [];
        $lead = $this->buildLead($topic, $plan, $coreData, $clusters);
        if ($lead !== '') { $paragraphs[] = $lead; $used[] = $this->fingerprint($lead); }
        $prevType = null;
        foreach (($plan['sections'] ?? []) as $section) {
            $sentences = [];
            foreach (($section['cluster_ids'] ?? []) as $cid) {
                if (!isset($clusterIndex[(string)$cid])) continue;
                $candidate = $this->cleanSentence((string)($clusterIndex[(string)$cid]['representative_claim'] ?? ''));
                if ($this->skipForLead($candidate) && $prevType === null) continue;
                $fp = $this->fingerprint($candidate);
                if ($candidate === '' || in_array($fp, $used, true) || $this->isNearDuplicate($candidate, $sentences)) continue;
                $sentences[] = $candidate; $used[] = $fp;
                if (count($sentences) >= 2) break;
            }
            if (!empty($sentences)) {
                $paragraph = implode(' ', $sentences);
                $bridge = $this->buildBridge($prevType, (string)($section['section_type'] ?? 'background'));
                if ($bridge !== '') $paragraph = $bridge . ' ' . $paragraph;
                $paragraphs[] = $paragraph;
                $prevType = (string)($section['section_type'] ?? 'background');
            }
        }
        return implode("

", $paragraphs);
    }

    public function getDeduplicationDebug(): array { return $this->deduplicationDebug; }

    private function buildLead(string $topic, ?array $plan, array $coreData, array $clusters): string
    {
        $topic = trim($topic);
        foreach (($coreData['core_facts'] ?? []) as $fact) {
            $claim = $this->cleanSentence((string)($fact['claim'] ?? ''));
            if ($claim !== '' && !$this->skipForLead($claim)) return $claim;
        }
        foreach ($clusters as $cluster) {
            if ((string)($cluster['dominant_discourse_type'] ?? '') !== 'definition') continue;
            $claim = $this->cleanSentence((string)($cluster['representative_claim'] ?? ''));
            if ($claim !== '' && !$this->skipForLead($claim)) return $claim;
        }
        $axis = (string)($plan['dominant_axis'] ?? '');
        if ($topic !== '' && $axis !== '' && !str_contains($axis, 'główny temat tego zestawu źródeł')) {
            return $axis . '.';
        }
        return $topic !== '' ? $topic . ' jest głównym tematem tego zestawu tekstów.' : 'Temat został zsyntetyzowany z wielu źródeł.';
    }

    private function buildBridge(?string $prevType, string $currentType): string
    {
        if ($prevType === null) return '';
        return match ($currentType) {
            'technical' => 'Na tle tego ogólnego znaczenia warto przyjrzeć się warunkom i uwarunkowaniom technicznym.',
            'practical' => 'Z tymi uwarunkowaniami wiążą się również skutki praktyczne i organizacyjne.',
            'background' => 'W szerszej perspektywie przekłada się to także na dalsze konsekwencje i kontekst.',
            'opinion' => 'Na tym tle pojawia się także szersza ocena i interpretacja.',
            default => '',
        };
    }

    private function skipForLead(string $candidate): bool
    {
        if ($candidate === '') return true;
        foreach ((array)($this->profile?->get('blocked_lead_openings', []) ?? []) as $blocked) {
            if ($blocked !== '' && preg_match('/^' . preg_quote((string)$blocked, '/') . '/iu', $candidate)) return true;
        }
        if (preg_match('/^(Konieczne jest|Wynika to|Ich przewagą jest|Z tymi|W szerszej perspektywie|Mają rację|Warunkiem jest)/iu', $candidate)) return true;
        if (preg_match('/^(to|ich|z tymi|w szerszej perspektywie)/iu', $candidate)) return true;
        return false;
    }

    private function isNearDuplicate(string $candidate, array $sentences): bool
    {
        foreach ($sentences as $sentence) {
            similar_text($this->fingerprint($candidate), $this->fingerprint($sentence), $pct);
            if ($pct >= 82.0) return true;
        }
        return false;
    }

    private function cleanSentence(string $raw): string
    {
        $s = trim($raw);
        $s = preg_replace('/\s+/u', ' ', $s) ?? $s;
        $s = preg_replace('/\s+([,.;:!?])/u', '$1', $s) ?? $s;
        if ($s === '') return '';
        if (!preg_match('/[.!?]$/u', $s)) $s .= '.';
        return $s;
    }

    private function fingerprint(string $s): string
    {
        $s = mb_strtolower(trim($s));
        $s = preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $s) ?? $s;
        $s = preg_replace('/\s+/u', ' ', $s) ?? $s;
        return trim($s);
    }
}
