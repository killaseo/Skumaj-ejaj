<?php
declare(strict_types=1);

namespace TextMixer;

use PDO;

final class VectorIndex
{
    private ?PDO $pdo = null;
    /** @var array<string,array<string,float>> */
    private array $cache = [];
    /** @var array<string,array<string,mixed>> */
    private array $metaCache = [];

    public function __construct(private string $sqlitePath) {}

    public function isAvailable(): bool
    {
        return is_file($this->sqlitePath);
    }

    private function pdo(): ?PDO
    {
        if (!$this->isAvailable()) {
            return null;
        }
        if ($this->pdo === null) {
            $this->pdo = new PDO('sqlite:' . $this->sqlitePath, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        }
        return $this->pdo;
    }

    /** @return array<string,float> */
    public function getVector(string $term): array
    {
        $term = $this->norm($term);
        if ($term === '') return [];
        if (isset($this->cache[$term])) return $this->cache[$term];
        $pdo = $this->pdo();
        if ($pdo === null) return [];
        $stmt = $pdo->prepare('SELECT vector, quality_score, term_freq, doc_freq, context_count FROM vectors WHERE term = :term LIMIT 1');
        $stmt->execute(['term' => $term]);
        $row = $stmt->fetch();
        if (!$row) {
            $this->cache[$term] = [];
            return [];
        }
        $this->metaCache[$term] = [
            'quality_score' => (float)($row['quality_score'] ?? 0),
            'term_freq' => (int)($row['term_freq'] ?? 0),
            'doc_freq' => (int)($row['doc_freq'] ?? 0),
            'context_count' => (int)($row['context_count'] ?? 0),
        ];
        $vec = [];
        foreach (preg_split('/\s+/', trim((string)$row['vector'])) ?: [] as $pair) {
            $pos = strrpos($pair, ':');
            if ($pos === false) continue;
            $k = substr($pair, 0, $pos);
            $v = (float)substr($pair, $pos + 1);
            if ($k === '' || $v == 0.0) continue;
            $vec[$k] = $v;
        }
        $this->cache[$term] = $vec;
        return $vec;
    }

    public function getMeta(string $term): array
    {
        $term = $this->norm($term);
        if (!isset($this->metaCache[$term])) {
            $this->getVector($term);
        }
        return $this->metaCache[$term] ?? [];
    }

    public function similarity(string $a, string $b): float
    {
        $va = $this->getVector($a);
        $vb = $this->getVector($b);
        if (!$va || !$vb) return 0.0;
        return $this->cosine($va, $vb);
    }

    /** @param string[] $terms @return array<string,float> */
    public function centroid(array $terms): array
    {
        $out = [];
        $count = 0;
        foreach ($terms as $term) {
            $term = $this->norm($term);
            if ($term === '') continue;
            $meta = $this->getMeta($term);
            if (($meta['quality_score'] ?? 0) < 0.05) continue;
            $vec = $this->getVector($term);
            if (!$vec) continue;
            foreach ($vec as $dim => $value) {
                $out[$dim] = ($out[$dim] ?? 0.0) + $value;
            }
            $count++;
        }
        if ($count < 1) return [];
        foreach ($out as $dim => $value) {
            $out[$dim] = $value / $count;
        }
        return $out;
    }

    /** @param string[] $contextTerms */
    public function similarityToTerms(string $term, array $contextTerms): float
    {
        $vec = $this->getVector($term);
        if (!$vec) return 0.0;
        $centroid = $this->centroid($contextTerms);
        if (!$centroid) return 0.0;
        return $this->cosine($vec, $centroid);
    }

    /** @param string[] $termsA @param string[] $termsB */
    public function segmentSimilarity(array $termsA, array $termsB): float
    {
        $ca = $this->centroid($termsA);
        $cb = $this->centroid($termsB);
        if (!$ca || !$cb) return 0.0;
        return $this->cosine($ca, $cb);
    }

    /** @param array<string,float> $a @param array<string,float> $b */
    private function cosine(array $a, array $b): float
    {
        $dot = 0.0; $na = 0.0; $nb = 0.0;
        foreach ($a as $dim => $val) {
            $na += $val * $val;
            if (isset($b[$dim])) $dot += $val * $b[$dim];
        }
        foreach ($b as $val) $nb += $val * $val;
        if ($na <= 0.0 || $nb <= 0.0) return 0.0;
        return $dot / (sqrt($na) * sqrt($nb));
    }

    private function norm(string $term): string
    {
        $term = mb_strtolower(trim($term), 'UTF-8');
        $term = preg_replace('/[^\p{L}\p{N}\s\-]/u', ' ', $term) ?? $term;
        $term = preg_replace('/\s+/u', ' ', $term) ?? $term;
        return trim($term);
    }
}
