<?php
declare(strict_types=1);

namespace TextMixer;

/**
 * SimilarityEngine
 * Multi-layer similarity with stronger cross-source linking.
 */
class SimilarityEngine
{
    private const W_LEXICAL  = 0.18;
    private const W_KEYWORD  = 0.16;
    private const W_PHRASE   = 0.12;
    private const W_ENTITY   = 0.24;
    private const W_RELATION = 0.12;
    private const W_SURFACE  = 0.18;

    private const LINK_THRESHOLD = 0.16;

    /**
     * @param  array<string,mixed> $a
     * @param  array<string,mixed> $b
     * @return array{score: float, reason: string, detail: array<string,float|int|string>}
     */
    public function compare(array $a, array $b): array
    {
        $lexical   = $this->lexicalOverlap($a, $b);
        $keyword   = $this->keywordOverlap($a, $b);
        $phrase    = $this->phraseOverlap($a, $b);
        $entity    = $this->entityOverlap($a, $b);
        $relation  = $this->relationOverlap($a, $b);
        $surface   = $this->surfaceSimilarity($a, $b);
        $numeric   = $this->numberOverlap($a['raw'] ?? '', $b['raw'] ?? '');
        $sameAnchor = $this->sharesAnchorEntity($a, $b) ? 1.0 : 0.0;

        $score = $lexical  * self::W_LEXICAL
               + $keyword  * self::W_KEYWORD
               + $phrase   * self::W_PHRASE
               + $entity   * self::W_ENTITY
               + $relation * self::W_RELATION
               + $surface  * self::W_SURFACE;

        if ($sameAnchor > 0.0) {
            $score += 0.08;
        }
        if ($numeric > 0.0) {
            $score += min(0.06, $numeric * 0.06);
        }
        if ($entity > 0.0 && $relation > 0.0) {
            $score += 0.04;
        }

        $score = min(1.0, round($score, 4));

        return [
            'score' => $score,
            'reason' => $this->buildReason($score, $lexical, $keyword, $phrase, $entity, $relation, $surface, $sameAnchor, $numeric),
            'detail' => [
                'lexical' => round($lexical, 4),
                'keyword' => round($keyword, 4),
                'phrase' => round($phrase, 4),
                'entity' => round($entity, 4),
                'relation' => round($relation, 4),
                'surface' => round($surface, 4),
                'same_anchor' => (int) $sameAnchor,
                'numeric_overlap' => round($numeric, 4),
            ],
        ];
    }

    /** @param array<int,array<string,mixed>> $segments @return array<int,array<string,mixed>> */
    public function buildCrossSourceLinks(array $segments): array
    {
        $bySrc = [];
        foreach ($segments as $seg) {
            $bySrc[$seg['source_id']][] = $seg;
        }

        $srcIds = array_keys($bySrc);
        $links = [];
        for ($i = 0; $i < count($srcIds); $i++) {
            for ($j = $i + 1; $j < count($srcIds); $j++) {
                foreach ($bySrc[$srcIds[$i]] as $segA) {
                    foreach ($bySrc[$srcIds[$j]] as $segB) {
                        $cmp = $this->compare($segA, $segB);
                        if ($cmp['score'] < self::LINK_THRESHOLD) {
                            continue;
                        }
                        $links[] = [
                            'seg_a' => $segA['segment_id'],
                            'seg_b' => $segB['segment_id'],
                            'score' => $cmp['score'],
                            'reason' => $cmp['reason'],
                            'detail' => $cmp['detail'],
                        ];
                    }
                }
            }
        }

        usort($links, fn($a, $b) => $b['score'] <=> $a['score']);
        return $links;
    }

    private function lexicalOverlap(array $a, array $b): float
    {
        return $this->setJaccard($a['tokens'] ?? [], $b['tokens'] ?? []);
    }

    private function keywordOverlap(array $a, array $b): float
    {
        $kwA = [];
        foreach ($a['keywords'] ?? [] as $kw) {
            $kwA[$kw['word']] = max($kwA[$kw['word']] ?? 0.0, (float) ($kw['weight'] ?? 0.0));
        }
        $kwB = [];
        foreach ($b['keywords'] ?? [] as $kw) {
            $kwB[$kw['word']] = max($kwB[$kw['word']] ?? 0.0, (float) ($kw['weight'] ?? 0.0));
        }
        if (empty($kwA) || empty($kwB)) {
            return 0.0;
        }
        $shared = array_intersect_key($kwA, $kwB);
        if (empty($shared)) {
            return 0.0;
        }
        $inter = 0.0;
        foreach ($shared as $word => $_) {
            $inter += min($kwA[$word], $kwB[$word]);
        }
        $total = array_sum($kwA) + array_sum($kwB);
        return $total > 0.0 ? (2 * $inter) / $total : 0.0;
    }

    private function phraseOverlap(array $a, array $b): float
    {
        $phrasesA = array_map(static fn($p) => $p['phrase'], $a['phrases'] ?? []);
        $phrasesB = array_map(static fn($p) => $p['phrase'], $b['phrases'] ?? []);
        return $this->setJaccard($phrasesA, $phrasesB);
    }

    private function entityOverlap(array $a, array $b): float
    {
        return $this->setJaccard($a['entities'] ?? [], $b['entities'] ?? []);
    }

    private function relationOverlap(array $a, array $b): float
    {
        $relA = array_map(fn($r) => strtolower(($r['predicate'] ?? '') . '|' . ($r['object'] ?? '')), $a['relations'] ?? []);
        $relB = array_map(fn($r) => strtolower(($r['predicate'] ?? '') . '|' . ($r['object'] ?? '')), $b['relations'] ?? []);
        if (!empty($relA) && !empty($relB)) {
            return $this->softSetOverlap($relA, $relB);
        }
        $predA = array_map(fn($r) => strtolower((string) ($r['predicate'] ?? '')), $a['relations'] ?? []);
        $predB = array_map(fn($r) => strtolower((string) ($r['predicate'] ?? '')), $b['relations'] ?? []);
        return $this->setJaccard($predA, $predB);
    }

    private function surfaceSimilarity(array $a, array $b): float
    {
        $s1 = $this->normaliseText($a['raw'] ?? $a['normalized'] ?? '');
        $s2 = $this->normaliseText($b['raw'] ?? $b['normalized'] ?? '');
        return $this->ngramJaccard($s1, $s2, 3);
    }

    private function numberOverlap(string $a, string $b): float
    {
        preg_match_all('/\b\d+(?:[.,]\d+)?\b/u', $a, $ma);
        preg_match_all('/\b\d+(?:[.,]\d+)?\b/u', $b, $mb);
        return $this->setJaccard($ma[0] ?? [], $mb[0] ?? []);
    }

    private function sharesAnchorEntity(array $a, array $b): bool
    {
        $aFirst = $a['entities'][0] ?? null;
        $bFirst = $b['entities'][0] ?? null;
        return $aFirst !== null && $aFirst === $bFirst;
    }

    /** @param array<int|string> $a @param array<int|string> $b */
    private function setJaccard(array $a, array $b): float
    {
        $a = array_values(array_unique(array_filter($a, fn($v) => $v !== '' && $v !== null)));
        $b = array_values(array_unique(array_filter($b, fn($v) => $v !== '' && $v !== null)));
        if (empty($a) || empty($b)) {
            return 0.0;
        }
        $inter = count(array_intersect($a, $b));
        $union = count($a) + count($b) - $inter;
        return $union > 0 ? $inter / $union : 0.0;
    }

    /** @param string[] $a @param string[] $b */
    private function softSetOverlap(array $a, array $b): float
    {
        if (empty($a) || empty($b)) {
            return 0.0;
        }
        $hits = 0;
        foreach ($a as $itemA) {
            foreach ($b as $itemB) {
                similar_text($itemA, $itemB, $pct);
                if ($pct >= 72.0) {
                    $hits++;
                    break;
                }
            }
        }
        $union = count(array_unique($a)) + count(array_unique($b)) - $hits;
        return $union > 0 ? $hits / $union : 0.0;
    }

    private function normaliseText(string $text): string
    {
        $text = strtolower($text);
        $text = preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $text) ?? $text;
        return trim((string) preg_replace('/\s+/', ' ', $text));
    }

    private function ngramJaccard(string $a, string $b, int $n): float
    {
        $aSet = $this->ngrams($a, $n);
        $bSet = $this->ngrams($b, $n);
        if (empty($aSet) || empty($bSet)) {
            return 0.0;
        }
        $inter = count(array_intersect_key($aSet, $bSet));
        $union = count($aSet) + count($bSet) - $inter;
        return $union > 0 ? $inter / $union : 0.0;
    }

    /** @return array<string,true> */
    private function ngrams(string $text, int $n): array
    {
        $text = ' ' . $text . ' ';
        $out = [];
        $len = mb_strlen($text);
        if ($len < $n) {
            return [];
        }
        for ($i = 0; $i <= $len - $n; $i++) {
            $gram = mb_substr($text, $i, $n);
            $out[$gram] = true;
        }
        return $out;
    }

    private function buildReason(float $score, float $lexical, float $keyword, float $phrase, float $entity, float $relation, float $surface, float $sameAnchor, float $numeric): string
    {
        $parts = [];
        if ($sameAnchor > 0.0) $parts[] = 'same-anchor';
        if ($entity >= 0.20) $parts[] = 'entity-overlap';
        if ($relation >= 0.18) $parts[] = 'relation-overlap';
        if ($keyword >= 0.16 || $phrase >= 0.16) $parts[] = 'shared-keyphrases';
        if ($lexical >= 0.22) $parts[] = 'lexical-match';
        if ($surface >= 0.22) $parts[] = 'surface-paraphrase';
        if ($numeric > 0.0) $parts[] = 'shared-numbers';
        if (empty($parts)) $parts[] = $score >= self::LINK_THRESHOLD ? 'weak-multi-layer' : 'below-threshold';
        return implode('+', $parts);
    }
}
