<?php
declare(strict_types=1);

namespace TextMixer;

class DiscourseClassifier
{
    private ?Profile $profile = null;
    private ?TopicContext $topicContext = null;

    public function __construct(?Profile $profile = null)
    {
        $this->profile = $profile;
    }

    public function setRuntimeContext(Profile $profile, TopicContext $topicContext): void
    {
        $this->profile = $profile;
        $this->topicContext = $topicContext;
    }

    public function classifySegments(array $segments): array
    {
        $debug = ['segments' => []];
        foreach ($segments as &$seg) {
            $raw = trim((string)($seg['raw'] ?? ''));
            [$type, $scores, $signals] = $this->classifyWithScores($raw);
            $seg['discourse_type'] = $type;
            $debug['segments'][] = [
                'segment_id' => $seg['segment_id'],
                'discourse_type' => $type,
                'raw' => $raw,
                'scores' => $scores,
                'signals' => $signals,
            ];
        }
        unset($seg);
        return ['segments' => $segments, 'debug' => $debug];
    }

    public function classifyClusters(array $clusters, array $segments): array
    {
        $segIndex = [];
        foreach ($segments as $seg) $segIndex[(string)$seg['segment_id']] = $seg;
        $debug = ['clusters' => []];
        foreach ($clusters as &$cluster) {
            $dist = [];
            foreach (($cluster['segment_ids'] ?? []) as $sid) {
                $type = (string)($segIndex[(string)$sid]['discourse_type'] ?? 'background');
                $dist[$type] = ($dist[$type] ?? 0) + 1;
            }
            arsort($dist);
            $dominant = (string)(array_key_first($dist) ?? 'background');
            $cluster['dominant_discourse_type'] = $dominant;
            $cluster['discourse_distribution'] = $dist;
            $debug['clusters'][] = [
                'cluster_id' => $cluster['cluster_id'],
                'dominant_discourse_type' => $dominant,
                'distribution' => $dist,
                'representative_claim' => $cluster['representative_claim'] ?? '',
            ];
        }
        unset($cluster);
        return ['clusters' => $clusters, 'debug' => $debug];
    }

    /** @return array{0:string,1:array<string,float>,2:array<int,string>} */
    private function classifyWithScores(string $raw): array
    {
        $text = mb_strtolower($raw, 'UTF-8');
        $scores = [
            'definition' => 0.0,
            'news' => 0.0,
            'technical' => 0.0,
            'background' => 0.0,
            'opinion' => 0.0,
            'speculative' => 0.0,
            'practical' => 0.0,
            'fragment' => 0.0,
        ];
        $signals = [];

        if (mb_strlen($text, 'UTF-8') < 18) {
            $scores['fragment'] += 3.0;
            return ['fragment', $scores, ['short_fragment']];
        }

        $rules = [
            'news' => [
                '/\b(dzisiaj|dziś|rano|wieczorem|ogłosił(?:a|o)?|start|wystartowała|misja|rakieta|sonda|zgodnie z planem|dotrze|orbit[ęa]|lądowani[ea]|celem misji|canaveral|jezero)\b/iu' => 2.0,
            ],
            'technical' => [
                '/\b(ciśnienie|atmosfera|dwutlenk|azot|argon|temperatur|hpa|co2|składa się|wynosi średnio|model|algorytm|danych? treningowych|walidacj|czułość|swoistość|kliniczn|tomograf|rezonans|mammograf|obrazów?|laboratoryjn|uczenia maszynowego|głębokiego)\b/iu' => 2.0,
            ],
            'practical' => [
                '/\b(wdrażanie|bezpieczeństw|odpowiedzialnoś|nadzorem|lekarzy|lekarza|pacjenta|opieki|nie zastępują lekarzy|funkcję wspierającą|końcową ocenę)\b/iu' => 1.8,
            ],
            'opinion' => [
                '/\b(moim zdaniem|uważam|z drugiej strony|niepokój|nadzieję|sceptycy)\b/iu' => 2.0,
            ],
            'speculative' => [
                '/\b(czy .*\?|przyszłość|prędzej czy później|nieuniknion|mogłaby|może stać się|kolonizacja|międzyplanetarnym)\b/iu' => 2.0,
            ],
            'definition' => [
                '/\b([\p{L}\-]+(?:\s+[\p{L}\-]+){0,3})\s+(to|jest|są|stanowi|staje się|są wykorzystywane|wykorzystują)\b/iu' => 1.4,
            ],
            'background' => [
                '/\b(coraz więcej|w praktyce|z tego względu|zwolennicy|specjaliści zaznaczają|poza tym|w dłuższej perspektywie)\b/iu' => 1.1,
            ],
        ];

        foreach ($rules as $type => $patterns) {
            foreach ($patterns as $rx => $weight) {
                if (preg_match($rx, $raw)) {
                    $scores[$type] += $weight;
                    $signals[] = $type . ':' . $rx;
                }
            }
        }

        // medical profile bias
        if ($this->profile && $this->profile->getName() === 'medical_abstract') {
            $scores['technical'] += 0.5;
            if (preg_match('/\b(moim zdaniem|z drugiej strony)\b/iu', $raw)) $scores['opinion'] += 0.5;
        }

        arsort($scores);
        $type = (string)array_key_first($scores);
        if (($scores[$type] ?? 0.0) <= 0.0) {
            $type = 'background';
        }
        return [$type, $scores, $signals];
    }
}
