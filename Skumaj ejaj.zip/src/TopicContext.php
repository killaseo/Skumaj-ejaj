<?php
declare(strict_types=1);

namespace TextMixer;

final class TopicContext
{
    public function __construct(
        public readonly string $mainTopicPhrase,
        public readonly array $topicEntities,
        public readonly array $topicKeywords,
        public readonly array $dominantRelations,
        public readonly array $candidateSections,
        public readonly array $profileHints = []
    ) {}

    public function asArray(): array
    {
        return [
            'main_topic_phrase' => $this->mainTopicPhrase,
            'topic_entities' => $this->topicEntities,
            'topic_keywords' => $this->topicKeywords,
            'dominant_relations' => $this->dominantRelations,
            'candidate_sections' => $this->candidateSections,
            'profile_hints' => $this->profileHints,
        ];
    }
}
