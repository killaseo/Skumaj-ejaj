<?php
declare(strict_types=1);

namespace TextMixer;

/**
 * CoreExtractor
 * Core facts are built primarily from cross-source clusters, not from almost
 * exact sentence matches only.
 */
class CoreExtractor
{
    private const SCORE_SECONDARY = 0.04;
    private const SCORE_OPTIONAL  = 0.015;
    private const MIN_TOKEN_COUNT = 4;

    private SimilarityEngine $similarity;

    public function __construct(?SimilarityEngine $similarity = null)
    {
        $this->similarity = $similarity ?? new SimilarityEngine();
    }

    /**
     * @param  array<int,array<string,mixed>> $segments
     * @param  array<int,array<string,mixed>> $clusters
     * @param  array<string,array<string,mixed>> $entityRegistry
     * @return array<string,mixed>
     */
    public function extract(array $segments, array $clusters, array $entityRegistry): array
    {
        $topicEntity = $this->detectTopicEntity($entityRegistry);
        $segIndex = [];
        foreach ($segments as $seg) {
            $segIndex[$seg['segment_id']] = $seg;
        }

        $links = $this->similarity->buildCrossSourceLinks($segments);
        $linksBySeg = [];
        foreach ($links as $link) {
            $linksBySeg[$link['seg_a']][] = $link;
            $linksBySeg[$link['seg_b']][] = $link;
        }

        $clusterById = [];
        foreach ($clusters as $cluster) {
            $clusterById[$cluster['cluster_id']] = $cluster;
        }

        $coreFacts = [];
        $secondary = [];
        $optional = [];
        $noise = [];
        $coreSegIds = [];
        $coreDebug = [];

        usort($clusters, fn($a, $b) => $b['consensus_level'] <=> $a['consensus_level']);
        foreach ($clusters as $cluster) {
            $clusterSegs = [];
            foreach ($cluster['segment_ids'] as $sid) {
                if (isset($segIndex[$sid])) {
                    $clusterSegs[] = $segIndex[$sid];
                }
            }
            if (empty($clusterSegs)) {
                continue;
            }

            $sourceIds = array_values(array_unique(array_column($clusterSegs, 'source_id')));
            $supports = $this->collectClusterSupport($clusterSegs, $links);
            $agreement = $supports['agreement_score'];
            $rep = $this->pickRepresentative($clusterSegs, $supports['best_supported_segment_id']);
            $fact = [
                'segment_id' => $rep['segment_id'],
                'source_id' => $rep['source_id'],
                'raw' => $rep['raw'],
                'score' => $rep['score'],
                'claim' => $rep['raw'],
                'representative_claim' => $rep['raw'],
                'sources' => $sourceIds,
                'segments' => array_values(array_map(fn($s) => $s['segment_id'], $clusterSegs)),
                'agreement_score' => round($agreement, 4),
                'consensus_type' => count($sourceIds) >= 3 ? 'broad' : 'partial',
                'sources_agreeing' => count($sourceIds),
                'source_count' => count($sourceIds),
                'shared_entities' => $this->sharedEntities($clusterSegs),
                'cluster_id' => $cluster['cluster_id'],
                'support_links' => $supports['support_links'],
            ];

            $isCore = count($sourceIds) >= 2 && ($agreement >= 0.16 || $cluster['consensus_level'] >= 0.5 || !empty($fact['shared_entities']));
            if ($isCore) {
                $coreFacts[] = $fact;
                foreach ($fact['segments'] as $sid) {
                    $coreSegIds[$sid] = true;
                }
                $coreDebug[] = [
                    'cluster_id' => $cluster['cluster_id'],
                    'sources' => $sourceIds,
                    'agreement_score' => round($agreement, 4),
                    'support_count' => count($supports['support_links']),
                    'representative_segment_id' => $rep['segment_id'],
                ];
            }
        }

        foreach ($segments as $seg) {
            if (isset($coreSegIds[$seg['segment_id']])) {
                continue;
            }
            $entry = [
                'segment_id' => $seg['segment_id'],
                'source_id' => $seg['source_id'],
                'raw' => $seg['raw'],
                'score' => $seg['score'],
                'sources_agreeing' => 1,
                'sources' => [$seg['source_id']],
                'source_count' => 1,
                'shared_entities' => $seg['entities'],
                'representative_claim' => $seg['raw'],
				'merge_reason' => isset($seg['cluster_id'], $clusterById[$seg['cluster_id']])
    ? 'single-source-cluster:' . ($clusterById[$seg['cluster_id']]['theme_guess'] ?? $clusterById[$seg['cluster_id']]['dominant_discourse_type'] ?? 'unknown')
    : 'single_source',
                'entities' => $seg['entities'],
                'relations' => array_map(fn($r) => ($r['predicate'] ?? '') . ': ' . ($r['object'] ?? ''), $seg['relations'] ?? []),
                'cluster_id' => $seg['cluster_id'],
            ];

            $tokenCount = count($seg['tokens'] ?? []);
            if ($tokenCount < self::MIN_TOKEN_COUNT || $seg['score'] < self::SCORE_OPTIONAL) {
                $noise[] = $entry;
            } elseif ($seg['score'] >= self::SCORE_SECONDARY || !empty($seg['entities']) || !empty($seg['relations'])) {
                $secondary[] = $entry;
            } else {
                $optional[] = $entry;
            }
        }

        usort($coreFacts, fn($a, $b) => ($b['agreement_score'] <=> $a['agreement_score']) ?: ($b['score'] <=> $a['score']));
        usort($secondary, fn($a, $b) => $b['score'] <=> $a['score']);
        usort($optional, fn($a, $b) => $b['score'] <=> $a['score']);

        return [
            'topic_entity' => $topicEntity,
            'core_facts' => $coreFacts,
            'secondary_facts' => $secondary,
            'optional_details' => $optional,
            'discarded_noise' => $noise,
            '_debug' => [
                'core_facts_count' => count($coreFacts),
                'core_groups_found' => count($coreFacts),
                'segments_per_core_fact' => array_values(array_map(fn($f) => count($f['segments']), $coreFacts)),
                'cross_source_links' => count($links),
                'cross_source_links_preview' => array_slice($links, 0, 40),
                'core_cluster_debug' => $coreDebug,
            ],
        ];
    }

    /** @param array<int,array<string,mixed>> $clusterSegs @param array<int,array<string,mixed>> $links @return array<string,mixed> */
    private function collectClusterSupport(array $clusterSegs, array $links): array
    {
        $segIdSet = array_flip(array_map(fn($s) => $s['segment_id'], $clusterSegs));
        $supportLinks = [];
        $supportCount = [];
        $scores = [];
        foreach ($links as $link) {
            if (isset($segIdSet[$link['seg_a']], $segIdSet[$link['seg_b']])) {
                $supportLinks[] = $link;
                $scores[] = $link['score'];
                $supportCount[$link['seg_a']] = ($supportCount[$link['seg_a']] ?? 0) + 1;
                $supportCount[$link['seg_b']] = ($supportCount[$link['seg_b']] ?? 0) + 1;
            }
        }
        arsort($supportCount);
        return [
            'agreement_score' => !empty($scores) ? array_sum($scores) / count($scores) : 0.0,
            'support_links' => $supportLinks,
            'best_supported_segment_id' => array_key_first($supportCount),
        ];
    }

    /** @param array<int,array<string,mixed>> $clusterSegs */
    private function pickRepresentative(array $clusterSegs, ?string $bestSupportedSegmentId): array
    {
        usort($clusterSegs, function (array $a, array $b) use ($bestSupportedSegmentId): int {
            $aScore = ($a['score'] ?? 0) + (($a['segment_id'] === $bestSupportedSegmentId) ? 0.25 : 0.0) + strlen((string) $a['raw']) / 400;
            $bScore = ($b['score'] ?? 0) + (($b['segment_id'] === $bestSupportedSegmentId) ? 0.25 : 0.0) + strlen((string) $b['raw']) / 400;
            return $bScore <=> $aScore;
        });
        return $clusterSegs[0];
    }

    /** @param array<int,array<string,mixed>> $groupSegs @return array<int,string> */
    private function sharedEntities(array $groupSegs): array
    {
        if (empty($groupSegs)) return [];
        $shared = $groupSegs[0]['entities'] ?? [];
        foreach (array_slice($groupSegs, 1) as $seg) {
            $shared = array_values(array_intersect($shared, $seg['entities'] ?? []));
        }
        if (!empty($shared)) {
            return array_values(array_unique($shared));
        }
        $all = [];
        foreach ($groupSegs as $seg) {
            foreach ($seg['entities'] ?? [] as $eid) {
                $all[$eid] = ($all[$eid] ?? 0) + 1;
            }
        }
        arsort($all);
        return array_slice(array_keys($all), 0, 3);
    }

    /** @param array<string,array<string,mixed>> $entityRegistry */
    private function detectTopicEntity(array $entityRegistry): string
    {
        $best = null;
        $bestScore = -1;
        foreach ($entityRegistry as $entity) {
            if (($entity['type'] ?? '') === 'DATE') continue;
            $score = array_sum($entity['source_mentions'] ?? []) + count($entity['segment_ids'] ?? []);
            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $entity['name'];
            }
        }
        return $best ?? 'Unknown';
    }
}
