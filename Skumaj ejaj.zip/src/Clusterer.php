<?php
declare(strict_types=1);

namespace TextMixer;

class Clusterer
{
    private float $threshold;
    private int $counter = 0;
    private SimilarityEngine $similarity;

    public function __construct(float $similarityThreshold = 0.18, ?SimilarityEngine $similarity = null)
    {
        $this->threshold = $similarityThreshold;
        $this->similarity = $similarity ?? new SimilarityEngine();
    }

    /** @param array<int,array<string,mixed>> $segments @param array<string,array<string,mixed>> $entityRegistry @return array{segments: array, clusters: array, cluster_debug: array<int,array<string,mixed>>} */
    public function cluster(array $segments, array $entityRegistry): array
    {
        $registryById = [];
        foreach ($entityRegistry as $entity) {
            $registryById[$entity['entity_id']] = $entity;
        }

        foreach ($segments as &$seg) {
            $seg['_anchor_entity'] = $this->pickAnchorEntity($seg, $registryById);
            $seg['_theme_key'] = $this->buildThemeKey($seg);
            $seg['_register_key'] = $this->inferRegister((string)($seg['raw'] ?? ''));
        }
        unset($seg);

        usort($segments, function (array $a, array $b): int {
            $aWeight = ($a['score'] ?? 0) + (count($a['entities'] ?? []) * 0.2) + (count($a['relations'] ?? []) * 0.1);
            $bWeight = ($b['score'] ?? 0) + (count($b['entities'] ?? []) * 0.2) + (count($b['relations'] ?? []) * 0.1);
            return $bWeight <=> $aWeight;
        });

        $clusterMap = [];
        $clusterDebug = [];
        foreach ($segments as $seg) {
            $bestClusterId = null;
            $bestScore = -1.0;
            $bestReason = 'new-cluster';
            foreach ($clusterMap as $cid => $cluster) {
                $cmp = $this->scoreAgainstCluster($seg, $cluster);
                if ($cmp['score'] > $bestScore) {
                    $bestScore = $cmp['score'];
                    $bestClusterId = $cid;
                    $bestReason = $cmp['reason'];
                }
            }

            $shouldAttach = $bestClusterId !== null && (
                $bestScore >= $this->threshold
                || ($this->shareAnchor($seg, $clusterMap[$bestClusterId]) && $bestScore >= 0.16)
                || ($this->shareAnchor($seg, $clusterMap[$bestClusterId]) && $this->shareTheme($seg, $clusterMap[$bestClusterId]) && $this->compatibleRegister($seg, $clusterMap[$bestClusterId]) && $bestScore >= 0.12)
            );

            if (!$shouldAttach) {
                $bestClusterId = $this->newClusterId();
                $clusterMap[$bestClusterId] = [
                    'cluster_id' => $bestClusterId,
                    'members' => [],
                    'representative' => $seg,
                    'anchors' => [],
                    'themes' => [],
                    'source_ids' => [],
                    'registers' => [],
                ];
                $bestReason = 'seed-cluster';
            }

            $clusterMap[$bestClusterId]['members'][] = $seg;
            $clusterMap[$bestClusterId]['source_ids'][$seg['source_id']] = true;
            if (!empty($seg['_anchor_entity'])) $clusterMap[$bestClusterId]['anchors'][$seg['_anchor_entity']] = true;
            if (!empty($seg['_theme_key'])) $clusterMap[$bestClusterId]['themes'][$seg['_theme_key']] = true;
            if (!empty($seg['_register_key'])) $clusterMap[$bestClusterId]['registers'][$seg['_register_key']] = true;
            if ($this->shouldReplaceRepresentative($seg, $clusterMap[$bestClusterId]['representative'])) {
                $clusterMap[$bestClusterId]['representative'] = $seg;
            }
            $clusterDebug[] = [
                'segment_id' => $seg['segment_id'],
                'cluster_id' => $bestClusterId,
                'assignment_score' => round(max(0.0, $bestScore), 4),
                'assignment_reason' => $bestReason,
                'anchor_entity' => $seg['_anchor_entity'],
                'theme_key' => $seg['_theme_key'],
                'register_key' => $seg['_register_key'],
            ];
        }

        $clusterMap = $this->mergeCloseClusters($clusterMap);

        $clusters = [];
        $segCluster = [];
        foreach ($clusterMap as $cid => $cluster) {
            $members = $cluster['members'];
            usort($members, fn($a, $b) => $b['score'] <=> $a['score']);
            foreach ($members as $member) {
                $segCluster[$member['segment_id']] = $cid;
            }
            $clusters[] = $this->buildCluster($cid, $members, $entityRegistry);
        }

        foreach ($segments as &$seg) {
            $seg['cluster_id'] = $segCluster[$seg['segment_id']] ?? null;
            unset($seg['_anchor_entity'], $seg['_theme_key'], $seg['_register_key']);
        }
        unset($seg);

        return ['segments' => $segments, 'clusters' => $clusters, 'cluster_debug' => $clusterDebug];
    }

    /** @param array<string,mixed> $seg @param array<string,mixed> $cluster */
    private function scoreAgainstCluster(array $seg, array $cluster): array
    {
        $rep = $cluster['representative'];
        $cmpRep = $this->similarity->compare($seg, $rep);

        $memberScores = [];
        foreach (array_slice($cluster['members'], 0, 3) as $member) {
            $memberScores[] = $this->similarity->compare($seg, $member)['score'];
        }
        $avg = !empty($memberScores) ? array_sum($memberScores) / count($memberScores) : 0.0;
        $score = max($cmpRep['score'], $avg);
        $reason = $cmpRep['reason'];

        if ($this->shareAnchor($seg, $cluster)) {
            $score += 0.05;
            $reason .= '+cluster-anchor';
        }
        if ($this->shareTheme($seg, $cluster)) {
            $score += 0.04;
            $reason .= '+theme';
        }
        if (!$this->compatibleRegister($seg, $cluster)) {
            $score -= 0.18;
            $reason .= '+register-penalty';
        }

        return ['score' => min(1.0, round(max(0.0, $score), 4)), 'reason' => trim($reason, '+')];
    }

    /** @param array<string,mixed> $seg @param array<string,mixed> $cluster */
    private function shareAnchor(array $seg, array $cluster): bool
    {
        $anchor = $seg['_anchor_entity'] ?? null;
        return $anchor !== null && isset($cluster['anchors'][$anchor]);
    }

    /** @param array<string,mixed> $seg @param array<string,mixed> $cluster */
    private function shareTheme(array $seg, array $cluster): bool
    {
        $theme = $seg['_theme_key'] ?? null;
        return $theme !== null && isset($cluster['themes'][$theme]);
    }

    /** @param array<string,mixed> $seg @param array<string,mixed> $cluster */
    private function compatibleRegister(array $seg, array $cluster): bool
    {
        $reg = $seg['_register_key'] ?? 'background';
        if ($reg === 'fragment') return false;
        if (isset($cluster['registers'][$reg])) return true;
        $clusterRegs = array_keys($cluster['registers'] ?? []);
        if ($reg === 'background') {
            return in_array('technical', $clusterRegs, true) || in_array('news', $clusterRegs, true) || in_array('definition', $clusterRegs, true);
        }
        if ($reg === 'opinion' && in_array('speculative', $clusterRegs, true)) return true;
        if ($reg === 'speculative' && in_array('opinion', $clusterRegs, true)) return true;
        if ($reg === 'definition' && (in_array('technical', $clusterRegs, true) || in_array('news', $clusterRegs, true) || in_array('background', $clusterRegs, true))) return true;
        if ($reg === 'technical' && in_array('definition', $clusterRegs, true)) return true;
        if ($reg === 'news' && in_array('background', $clusterRegs, true)) return true;
        return false;
    }

    /** @param array<string,mixed> $seg @param array<string,array<string,mixed>> $registryById */
    private function pickAnchorEntity(array $seg, array $registryById): ?string
    {
        $best = null;
        $bestScore = -1;
        foreach ($seg['entities'] ?? [] as $entityId) {
            $entity = $registryById[$entityId] ?? null;
            if ($entity === null) continue;
            if (($entity['type'] ?? '') === 'DATE') continue;
            $score = array_sum($entity['source_mentions'] ?? []) + count($entity['segment_ids'] ?? []);
            if ($score > $bestScore) {
                $best = $entityId;
                $bestScore = $score;
            }
        }
        return $best;
    }

    /** @param array<string,mixed> $seg */
    private function buildThemeKey(array $seg): string
    {
        $predicates = array_map(fn($r) => strtolower((string)$r['predicate']), $seg['relations'] ?? []);
        if (!empty($predicates)) {
            sort($predicates);
            return 'rel:' . implode('|', array_slice(array_unique($predicates), 0, 2));
        }
        $phrases = array_map(fn($p) => strtolower((string)$p['phrase']), $seg['phrases'] ?? []);
        if (!empty($phrases)) {
            sort($phrases);
            return 'phr:' . implode('|', array_slice(array_unique($phrases), 0, 2));
        }
        $keywords = array_map(fn($k) => strtolower((string)$k['word']), $seg['keywords'] ?? []);
        sort($keywords);
        return 'kw:' . implode('|', array_slice(array_unique($keywords), 0, 3));
    }

    private function inferRegister(string $raw): string
    {
        $t = mb_strtolower($raw);
        if (preg_match('/\b(mają rację)\b/u', $t) || mb_strlen(trim($t)) < 18) return 'fragment';
        if (preg_match('/\b(dzisiaj|start|rakieta|sonda|misja|orbitę|lądowania|canaveral|jezero|kraterze)\b/u', $t)) return 'news';
        if (preg_match('/\b(ciśnienie|atmosfera|dwutlenk|temperatur|hpa|°c|argon|azot|gazow|cieplarnian|powłok)\b/u', $t)) return 'technical';
        if (preg_match('/\b(korzyści|innowacje|oczyszczania wody|materiałów)\b/u', $t)) return 'practical';
        if (preg_match('/\b(moim zdaniem|sceptycy|musimy|naturze)\b/u', $t)) return 'opinion';
        if (preg_match('/\b(kolonizacja|przyszłość|międzyplanetarnym)\b/u', $t) || str_contains($t, '?')) return 'speculative';
        if (preg_match('/\b(głównym celem|z powodu|skutkuje to)\b/u', $t)) return 'background';
        return 'background';
    }

    /** @param array<string,mixed> $candidate @param array<string,mixed> $current */
    private function shouldReplaceRepresentative(array $candidate, array $current): bool
    {
        $candidateScore = ($candidate['score'] ?? 0) + strlen((string)($candidate['raw'] ?? '')) / 300;
        $currentScore = ($current['score'] ?? 0) + strlen((string)($current['raw'] ?? '')) / 300;
        return $candidateScore > $currentScore;
    }

    /** @param array<string,array<string,mixed>> $clusterMap @return array<string,array<string,mixed>> */
    private function mergeCloseClusters(array $clusterMap): array
    {
        $keys = array_keys($clusterMap);
        for ($i = 0; $i < count($keys); $i++) {
            $aId = $keys[$i];
            if (!isset($clusterMap[$aId])) continue;
            for ($j = $i + 1; $j < count($keys); $j++) {
                $bId = $keys[$j];
                if (!isset($clusterMap[$bId])) continue;

                $cmp = $this->similarity->compare($clusterMap[$aId]['representative'], $clusterMap[$bId]['representative']);
                $sameAnchor = !empty(array_intersect_key($clusterMap[$aId]['anchors'], $clusterMap[$bId]['anchors']));
                $sameTheme = !empty(array_intersect_key($clusterMap[$aId]['themes'], $clusterMap[$bId]['themes']));
                $regsCompatible = $this->clusterRegistersCompatible($clusterMap[$aId]['registers'], $clusterMap[$bId]['registers']);
                if (($cmp['score'] >= 0.28 || ($sameAnchor && $sameTheme && $cmp['score'] >= 0.16) || ($sameAnchor && $cmp['score'] >= 0.2)) && $regsCompatible) {
                    $clusterMap[$aId]['members'] = array_merge($clusterMap[$aId]['members'], $clusterMap[$bId]['members']);
                    $clusterMap[$aId]['anchors'] += $clusterMap[$bId]['anchors'];
                    $clusterMap[$aId]['themes'] += $clusterMap[$bId]['themes'];
                    $clusterMap[$aId]['source_ids'] += $clusterMap[$bId]['source_ids'];
                    $clusterMap[$aId]['registers'] += $clusterMap[$bId]['registers'];
                    if ($this->shouldReplaceRepresentative($clusterMap[$bId]['representative'], $clusterMap[$aId]['representative'])) {
                        $clusterMap[$aId]['representative'] = $clusterMap[$bId]['representative'];
                    }
                    unset($clusterMap[$bId]);
                }
            }
        }
        return $clusterMap;
    }

    /** @param array<string,bool> $a @param array<string,bool> $b */
    private function clusterRegistersCompatible(array $a, array $b): bool
    {
        $aRegs = array_keys($a);
        $bRegs = array_keys($b);
        if (in_array('fragment', $aRegs, true) || in_array('fragment', $bRegs, true)) return false;
        if (!empty(array_intersect($aRegs, $bRegs))) return true;
        $pair = implode('|', [implode(',', $aRegs), implode(',', $bRegs)]);
        if (str_contains($pair, 'opinion') && str_contains($pair, 'speculative')) return true;
        if (str_contains($pair, 'technical') && str_contains($pair, 'definition')) return true;
        if (str_contains($pair, 'news') && str_contains($pair, 'background')) return true;
        return false;
    }

    /** @param array<int,array<string,mixed>> $members @param array<string,array<string,mixed>> $entityRegistry @return array<string,mixed> */
    private function buildCluster(string $cid, array $members, array $entityRegistry): array
    {
        $entityCounts = [];
        $sourceIds = [];
        foreach ($members as $m) {
            $sourceIds[$m['source_id']] = true;
            foreach ($m['entities'] ?? [] as $eid) {
                $entityCounts[$eid] = ($entityCounts[$eid] ?? 0) + 1;
            }
        }
        arsort($entityCounts);
        $mainEntities = [];
        foreach (array_slice(array_keys($entityCounts), 0, 4) as $eid) {
            foreach ($entityRegistry as $entity) {
                if (($entity['entity_id'] ?? '') === $eid) {
                    $mainEntities[] = $entity['name'];
                    break;
                }
            }
        }
        return [
            'cluster_id' => $cid,
            'segment_ids' => array_values(array_map(fn($m) => $m['segment_id'], $members)),
            'main_entities' => $mainEntities,
            'consensus_level' => round(count($sourceIds) / max(1, count($members)), 4),
            'representative_claim' => (string)($members[0]['raw'] ?? ''),
        ];
    }

    private function newClusterId(): string
    {
        $this->counter++;
        return sprintf('clu_%04d', $this->counter);
    }
}
