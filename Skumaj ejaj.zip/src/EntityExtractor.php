<?php
declare(strict_types=1);

namespace TextMixer;

class EntityExtractor
{
    private array $registry = [];
    private int $counter = 0;
    private ?Profile $profile = null;
    private ?TopicContext $topicContext = null;

    public function __construct(?Profile $profile = null)
    {
        $this->profile = $profile;
    }

    public function setRuntimeContext(Profile $profile, TopicContext $topicContext): void
    {
        $this->profile = $profile;
        $this->topicContext = $topicContext;
    }

    /** @param array<int,array<string,mixed>> $segments @return array<int,array<string,mixed>> */
    public function extract(array $segments): array
    {
        $this->registry = [];
        $this->counter = 0;

        $topicPhrases = [];
        if ($this->topicContext) {
            $topicPhrases[] = $this->topicContext->mainTopicPhrase;
            foreach ($this->topicContext->topicEntities as $e) $topicPhrases[] = (string)$e;
            foreach (($this->topicContext->profileHints['top_phrases'] ?? []) as $p) $topicPhrases[] = (string)$p;
        }
        foreach ($segments as &$seg) {
            $found = [];
            $raw = (string)($seg['raw'] ?? '');
            foreach ($this->findProfilePhrases($raw, $topicPhrases) as $phrase) {
                $found[] = $this->register($phrase, $this->guessType($phrase), $seg['segment_id'], $seg['source_id']);
            }
            foreach ($this->findCapitalizedEntities($raw) as $entity) {
                $found[] = $this->register($entity, $this->guessType($entity), $seg['segment_id'], $seg['source_id']);
            }
            foreach ($this->findConceptPhrases($raw) as $entity) {
                $found[] = $this->register($entity, $this->guessType($entity), $seg['segment_id'], $seg['source_id']);
            }
            $seg['entities'] = array_values(array_unique($found));
        }
        unset($seg);
        return $segments;
    }

    public function getRegistry(): array
    {
        return $this->registry;
    }

    /** @return string[] */
    private function findProfilePhrases(string $raw, array $topicPhrases): array
    {
        $hits = [];
        $patterns = (array)($this->profile?->get('topic_phrase_patterns', []) ?? []);
        foreach ($patterns as $rx) {
            if (@preg_match_all((string)$rx, $raw, $m)) {
                foreach (($m[0] ?? []) as $hit) {
                    $hit = trim((string)$hit);
                    if ($hit !== '') $hits[] = $hit;
                }
            }
        }
        foreach ($topicPhrases as $phrase) {
            $phrase = trim((string)$phrase);
            if ($phrase === '' || mb_strlen($phrase) < 4) continue;
            if (preg_match('/(?<!\p{L})' . preg_quote($phrase, '/') . '(?!\p{L})/iu', $raw)) {
                $hits[] = $phrase;
            }
        }
        return array_values(array_unique($hits));
    }

    /** @return string[] */
    private function findCapitalizedEntities(string $raw): array
    {
        $out = [];
        if (preg_match_all('/([\p{Lu}][\p{L}\-]+(?:\s+[\p{Lu}][\p{L}\-]+){0,3})/u', $raw, $m)) {
            foreach (($m[1] ?? []) as $cand) {
                $cand = trim((string)$cand);
                if (mb_strlen($cand) >= 3 && !preg_match('/^(Na|W|Z|Od|To|Ta|Ten|The|A|An)$/u', $cand)) {
                    $out[] = $cand;
                }
            }
        }
        return array_values(array_unique($out));
    }

    /** @return string[] */
    private function findConceptPhrases(string $raw): array
    {
        $out = [];
        if (!($this->profile?->get('concept_phrase_first', false) || $this->profile?->get('entity_phrase_first', false))) {
            return [];
        }
        if (preg_match_all('/([\p{Ll}ąćęłńóśźż]+\s+[\p{Ll}ąćęłńóśźż]+(?:\s+[\p{Ll}ąćęłńóśźż]+){0,2})/u', mb_strtolower($raw, 'UTF-8'), $m)) {
            foreach (($m[1] ?? []) as $cand) {
                $cand = trim((string)$cand);
                if (mb_strlen($cand) < 8) continue;
                if (preg_match('/(sztuczna inteligencja|diagnostyka medyczna|uczenie maszynowe|dane kliniczne|obrazy radiologiczne|morska energetyka wiatrowa|morskie farmy wiatrowe|energetyka odnawialna|system energetyczny|park krajobrazowy)/iu', $cand)) {
                    $out[] = mb_convert_case($cand, MB_CASE_TITLE, 'UTF-8');
                }
            }
        }
        return array_values(array_unique($out));
    }

    private function guessType(string $name): string
    {
        $n = mb_strtolower($name, 'UTF-8');
        if (preg_match('/(góra|szczyt|masyw|park|bałtyk|morze|wrocław|sobótka|polska|śląsk|mars)/u', $n)) return 'PLACE';
        if (preg_match('/(inteligencja|diagnostyka|uczenie|dane|obrazy|energetyka|farmy|infrastruktura|kolonizacja|eksploracja)/u', $n)) return 'CONCEPT';
        return preg_match('/\s/u', $name) ? 'PROPER' : 'PROPER';
    }

    private function register(string $name, string $type, string $segId, string $srcId): string
    {
        $canonical = trim($name);
        $key = $this->normaliseKey($canonical);
        if ($key === '') return '';
        if (!isset($this->registry[$key])) {
            $this->counter++;
            $this->registry[$key] = [
                'entity_id' => sprintf('ent_%04d', $this->counter),
                'name' => $canonical,
                'aliases' => [],
                'type' => $type,
                'source_mentions' => [],
                'segment_ids' => [],
            ];
        }
        $entity = &$this->registry[$key];
        if (!in_array($segId, $entity['segment_ids'], true)) $entity['segment_ids'][] = $segId;
        $entity['source_mentions'][$srcId] = ($entity['source_mentions'][$srcId] ?? 0) + 1;
        return $entity['entity_id'];
    }

    private function normaliseKey(string $text): string
    {
        $text = mb_strtolower(trim($text), 'UTF-8');
        $text = preg_replace('/[^\p{L}\p{N}\s\-]/u', ' ', $text) ?? $text;
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        return trim($text);
    }
}
