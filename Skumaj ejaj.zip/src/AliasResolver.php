<?php
declare(strict_types=1);

namespace TextMixer;

/**
 * AliasResolver
 * Merges entity variants that refer to the same real-world entity and exposes
 * an old_id => canonical_id map so segments can be remapped after resolution.
 */
class AliasResolver
{
    private const KNOWN_ALIASES = [
        ['sleza', 'gora sleza', 'mount sleza', 'zobtenberg', 'sleza massif', 'masyw slezy', 'the sleza massif'],
        ['sobotka', 'town of sobotka'],
        ['lower silesia', 'lower silesian', 'silesia', 'silesian'],
        ['sudeten', 'sudeten foreland', 'sudeten range'],
        ['landscape park', 'sleza landscape park'],
        ['st. anne', "st anne's church", "st. anne's church", "st. anne's chapel", 'summit chapel', 'summit church'],
        ['bronze age', 'bronze-age'],
        ['middle ages', 'medieval period', 'medieval'],
    ];

    /** @var array<string,string> */
    private array $resolvedEntityIdMap = [];

    /**
     * @param  array<string, array<string,mixed>> $registry
     * @return array<string, array<string,mixed>>
     */
    public function resolve(array $registry): array
    {
        $this->resolvedEntityIdMap = [];
        $parent = [];
        foreach ($registry as $key => $_) {
            $parent[(string) $key] = (string) $key;
        }

        foreach (self::KNOWN_ALIASES as $group) {
            $canonical = null;
            foreach ($group as $variant) {
                foreach (array_keys($registry) as $key) {
                    $key = (string) $key;
                    if ($this->isAliasLike($key, (string) $variant)) {
                        if ($canonical === null) {
                            $canonical = $key;
                        } else {
                            $parent[$this->find($parent, $key)] = $this->find($parent, $canonical);
                        }
                    }
                }
            }
        }

        $keys = array_map('strval', array_keys($registry));
        foreach ($keys as $a) {
            foreach ($keys as $b) {
                if ($a === $b) {
                    continue;
                }
                if ($this->shouldMergeByContainment($a, $b)) {
                    $ra = $this->find($parent, $a);
                    $rb = $this->find($parent, $b);
                    if ($ra !== $rb) {
                        $parent[$ra] = strlen($ra) <= strlen($rb) ? $ra : $rb;
                        $parent[$rb] = $parent[$ra];
                    }
                }
            }
        }

        foreach ($keys as $a) {
            foreach ($keys as $b) {
                if ($a >= $b) {
                    continue;
                }
                if (abs(strlen($a) - strlen($b)) > 3) {
                    continue;
                }
                if (levenshtein($a, $b) <= 2) {
                    $ra = $this->find($parent, $a);
                    $rb = $this->find($parent, $b);
                    if ($ra !== $rb) {
                        $parent[$ra] = strlen($ra) <= strlen($rb) ? $ra : $rb;
                        $parent[$rb] = $parent[$ra];
                    }
                }
            }
        }

        $groups = [];
        foreach ($keys as $k) {
            $root = $this->find($parent, $k);
            $groups[$root][] = $k;
        }

        $merged = [];
        foreach ($groups as $root => $members) {
            $canonicalKey = $this->pickCanonicalKey($members, $registry);
            $canonical = $registry[$canonicalKey];
            $canonical['aliases'] = [];

            foreach ($members as $memberKey) {
                $member = $registry[$memberKey];
                $this->resolvedEntityIdMap[$member['entity_id']] = $canonical['entity_id'];

                if ($memberKey !== $canonicalKey) {
                    $canonical['aliases'][] = $member['name'];
                }
                foreach ($member['aliases'] as $alias) {
                    $canonical['aliases'][] = $alias;
                }
                foreach ($member['source_mentions'] as $src => $cnt) {
                    $canonical['source_mentions'][$src] = max($canonical['source_mentions'][$src] ?? 0, 0) + $cnt;
                }
                foreach ($member['segment_ids'] as $sid) {
                    if (!in_array($sid, $canonical['segment_ids'], true)) {
                        $canonical['segment_ids'][] = $sid;
                    }
                }
            }

            $canonical['aliases'] = array_values(array_unique(array_filter($canonical['aliases'], fn($a) => strtolower($a) !== strtolower($canonical['name']))));
            $merged[$canonicalKey] = $canonical;
        }

        return $merged;
    }

    /** @return array<string,string> */
    public function getResolvedEntityIdMap(): array
    {
        return $this->resolvedEntityIdMap;
    }

    /** @param array<int,array<string,mixed>> $segments @return array<int,array<string,mixed>> */
    public function remapSegmentEntities(array $segments): array
    {
        if (empty($this->resolvedEntityIdMap)) {
            return $segments;
        }
        foreach ($segments as &$seg) {
            $mapped = [];
            foreach ($seg['entities'] ?? [] as $entityId) {
                $mapped[] = $this->resolvedEntityIdMap[$entityId] ?? $entityId;
            }
            $seg['entities'] = array_values(array_unique($mapped));
        }
        unset($seg);
        return $segments;
    }

    private function find(array &$parent, string $key): string
    {
        if (!isset($parent[$key])) {
            return $key;
        }
        if ($parent[$key] !== $key) {
            $parent[$key] = $this->find($parent, $parent[$key]);
        }
        return $parent[$key];
    }

    private function isAliasLike(string $a, string $b): bool
    {
        return $a === $b || str_contains($a, $b) || str_contains($b, $a);
    }

    private function shouldMergeByContainment(string $a, string $b): bool
    {
        if (strlen($a) < 5 || strlen($b) < 5) {
            return false;
        }
        return str_contains($a, $b) || str_contains($b, $a);
    }

    /** @param string[] $members @param array<string,array<string,mixed>> $registry */
    private function pickCanonicalKey(array $members, array $registry): string
    {
        usort($members, function (string $a, string $b) use ($registry): int {
            $scoreA = array_sum($registry[$a]['source_mentions']) + count($registry[$a]['segment_ids']);
            $scoreB = array_sum($registry[$b]['source_mentions']) + count($registry[$b]['segment_ids']);
            if ($scoreA !== $scoreB) {
                return $scoreB <=> $scoreA;
            }
            return strlen($a) <=> strlen($b);
        });
        return $members[0];
    }
}
