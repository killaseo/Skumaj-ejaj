<?php
declare(strict_types=1);

namespace TextMixer;

final class ProfileManager
{
    public function __construct(private string $profilesDir) {}

    public function load(string $profileName): Profile
    {
        $profilesDir = rtrim($this->profilesDir, '/');
        $path = $profilesDir . '/' . $profileName . '.php';
        if (!is_file($path)) {
            $path = $profilesDir . '/generic.php';
        }

        $data = require $path;
        if (!is_array($data)) {
            $data = require $profilesDir . '/generic.php';
        }

        return new Profile($data);
    }
}
