<?php
declare(strict_types=1);

namespace TextMixer;

class CompositionPlanner
{
    private ?Profile $profile = null;
    private ?TopicContext $topicContext = null;

    public function setRuntimeContext(Profile $profile, TopicContext $topicContext): void
    {
        $this->profile = $profile;
        $this->topicContext = $topicContext;
    }

    /** @param array<string,mixed> $coreData @param array<int,array<string,mixed>> $clusters @param array<int,array<string,mixed>> $segments @return array<string,mixed> */
    public function buildPlan(array $coreData, array $clusters, array $segments): array
    {
        $mainTopic = $this->topicContext?->mainTopicPhrase ?: (string)($coreData['topic_entity'] ?? 'Temat');
        $mode = $this->chooseMode($clusters);
        $axis = $this->buildDominantAxis($mainTopic);
        return [
            'composition_mode' => $mode,
            'main_topic_entity' => $mainTopic,
            'dominant_axis' => $axis,
            'sections' => $this->buildSections($mode, $clusters),
        ];
    }

    private function chooseMode(array $clusters): string
    {
        $dist = [];
        foreach ($clusters as $cluster) {
            $type = (string)($cluster['dominant_discourse_type'] ?? 'background');
            if ($type === 'fragment') continue;
            $dist[$type] = ($dist[$type] ?? 0) + 1;
        }
        arsort($dist);
        $kinds = count(array_filter($dist));
        $top = (int)(reset($dist) ?: 0);
        $total = max(1, array_sum($dist));
        $allowSectioned = (bool)($this->profile?->get('allow_sectioned_article', true) ?? true);
        $allowUnified = (bool)($this->profile?->get('allow_unified_article', true) ?? true);
        if ($allowSectioned && $kinds >= 3 && $top / $total < 0.62) return 'sectioned_article';
        if ((bool)($this->profile?->get('allow_dominant_axis_article', true) ?? true) && $kinds >= 2) return 'dominant_axis_article';
        return $allowUnified ? 'unified_article' : 'dominant_axis_article';
    }

    private function buildDominantAxis(string $mainTopic): string
    {
        $name = trim($mainTopic) !== '' ? trim($mainTopic) : 'Temat';
        $sections = (array)($this->topicContext?->candidateSections ?? []);
        if (in_array('technical', $sections, true) && in_array('practical', $sections, true)) {
            return $name . ' jako ważny element rozwoju, uwarunkowań technicznych i skutków praktycznych';
        }
        if (in_array('background', $sections, true) && in_array('definition', $sections, true)) {
            return $name . ' jako ważny temat łączący definicję, kontekst i dalsze konsekwencje';
        }
        return $name . ' jako główny temat tego zestawu źródeł';
    }

    private function buildSections(string $mode, array $clusters): array
    {
        $preferred = (array)($this->profile?->get('preferred_sections', ['definition','technical','practical','background']) ?? []);
        $buckets = [];
        foreach ($preferred as $p) $buckets[$p] = [];
        foreach ($clusters as $cluster) {
            $type = (string)($cluster['dominant_discourse_type'] ?? 'background');
            if ($type === 'fragment') continue;
            if (!isset($buckets[$type])) $type = 'background';
            $buckets[$type][] = (string)$cluster['cluster_id'];
        }
        $titles = [
            'definition' => 'Ujęcie ogólne',
            'news' => 'Bieżący kontekst',
            'technical' => 'Warunki i dane techniczne',
            'practical' => 'Wymagania i zastosowania',
            'background' => 'Szerszy kontekst',
            'opinion' => 'Szersza ocena',
        ];
        $sections = [];
        foreach ($preferred as $type) {
            if (empty($buckets[$type])) continue;
            $sections[] = ['section_type' => $type, 'title_hint' => $titles[$type] ?? 'Sekcja', 'cluster_ids' => array_slice($buckets[$type], 0, $type === 'background' ? 4 : 3)];
        }
        return $sections;
    }
}
