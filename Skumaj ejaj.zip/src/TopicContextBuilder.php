<?php
declare(strict_types=1);

namespace TextMixer;

final class TopicContextBuilder
{
    public function __construct(private ?VectorIndex $vectorIndex = null) {}

    /** @param array<int,array<string,mixed>> $segments */
    public function build(Profile $profile, array $segments): TopicContext
    {
        $phraseScores = [];
        $keywordScores = [];
        $sectionHints = [];
        $rawTexts = [];

        foreach ($segments as $seg) {
            $raw = (string)($seg['raw'] ?? '');
            if ($raw !== '') $rawTexts[] = $raw;
            $posBoost = ((int)($seg['position'] ?? 9) <= 1) ? 1.45 : 1.0;

            foreach ($this->extractCandidatePhrases($raw) as $phrase => $boost) {
                $phraseScores[$phrase] = ($phraseScores[$phrase] ?? 0.0) + ($boost * $posBoost);
            }

            foreach (($seg['phrases'] ?? []) as $phrase) {
                $p = $this->norm((string)($phrase['phrase'] ?? ''));
                if ($p === '' || !$this->isGoodTopicPhrase($p)) continue;
                $phraseScores[$p] = ($phraseScores[$p] ?? 0.0) + (((float)($phrase['score'] ?? 0.0) + 1.0) * $posBoost);
            }

            foreach (($seg['keywords'] ?? []) as $kw) {
                $w = $this->norm((string)($kw['word'] ?? ''));
                if (!$this->isUsefulKeyword($w)) continue;
                $keywordScores[$w] = max($keywordScores[$w] ?? 0.0, (float)($kw['weight'] ?? 0.0));
            }

            $sectionHints = array_merge($sectionHints, $this->sectionHintsFromText($raw));
        }

        // profile patterns are strong anchors
        foreach ((array)$profile->get('preferred_topic_patterns', []) as $pat) {
            $p = $this->norm((string)$pat);
            if ($this->isGoodTopicPhrase($p)) {
                $phraseScores[$p] = ($phraseScores[$p] ?? 0.0) + 3.0;
            }
        }

        foreach ($rawTexts as $raw) {
            foreach ((array)$profile->get('topic_phrase_patterns', []) as $rx) {
                if (@preg_match((string)$rx, $raw, $m)) {
                    $cand = $this->norm((string)($m[0] ?? ''));
                    if ($this->isGoodTopicPhrase($cand)) {
                        $phraseScores[$cand] = ($phraseScores[$cand] ?? 0.0) + 4.0;
                    }
                }
            }
        }

        arsort($phraseScores);
        arsort($keywordScores);

        $topKeywords = array_slice(array_keys($keywordScores), 0, 18);
        $main = $this->chooseMainPhrase($profile, $phraseScores, $topKeywords);
        if ($main === '') {
            $fallbackPhrase = $this->bestFallbackPhrase($rawTexts);
            $main = $fallbackPhrase !== '' ? $fallbackPhrase : ($topKeywords[0] ?? 'Temat');
        }

        $topicEntities = [$this->titleCase($main)];
        $candidateSections = array_values(array_unique(array_merge((array)$profile->get('preferred_sections', []), $sectionHints)));

        return new TopicContext(
            $this->titleCase($main),
            $topicEntities,
            $topKeywords,
            [],
            $candidateSections,
            [
                'top_phrases' => array_slice(array_keys($phraseScores), 0, 10),
                'fallback_phrase' => $this->bestFallbackPhrase($rawTexts),
            ]
        );
    }

    /** @param array<string,float> $phraseScores @param string[] $topKeywords */
    private function chooseMainPhrase(Profile $profile, array $phraseScores, array $topKeywords): string
    {
        $best = '';
        $bestScore = -INF;
        foreach ($phraseScores as $cand => $baseScore) {
            if (!$this->isGoodTopicPhrase($cand)) continue;
            $score = (float)$baseScore;
            $words = preg_split('/\s+/u', $cand) ?: [];
            $wordCount = count($words);

            if ($wordCount >= 2) $score += 1.8;
            if ($wordCount >= 3) $score += 0.6;
            if ($wordCount === 1) $score -= 2.4;
            if ((bool)$profile->get('entity_phrase_first', false) && $wordCount >= 2) $score += 1.0;
            if ((bool)$profile->get('concept_phrase_first', false) && $wordCount >= 2) $score += 1.0;

            foreach ((array)$profile->get('preferred_topic_patterns', []) as $pattern) {
                $pat = $this->norm((string)$pattern);
                if ($pat !== '' && (str_contains($cand, $pat) || str_contains($pat, $cand))) {
                    $score += 2.6;
                }
            }

            foreach ($topKeywords as $kw) {
                if (str_contains($cand, $kw)) $score += 0.55;
            }

            if ($this->vectorIndex) {
                $score += $this->vectorIndex->similarityToTerms($cand, $topKeywords) * 2.5;
            }

            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $cand;
            }
        }
        return $best;
    }

    /** @return array<string,float> */
    private function extractCandidatePhrases(string $raw): array
    {
        $out = [];
        $patterns = [
            '/\b([A-ZĄĆĘŁŃÓŚŹŻ][\p{L}\-]+(?:\s+[A-ZĄĆĘŁŃÓŚŹŻ][\p{L}\-]+){1,4})\b/u' => 2.0,
            '/\b([a-ząćęłńóśźż]+\s+(?:inteligencj[aey]|diagnostyk[aeyi]|medyczn[aey]|kliniczn[aey]|radiologiczn[aey]|wiatrow[aey]|offshore|energetyk[aeyi]))\b/iu' => 2.4,
            '/\b(sztuczn[aey]\s+inteligencj[aai](?:\s+w\s+diagnostyce\s+medycznej)?)\b/iu' => 3.2,
            '/\b(diagnostyk[aai]\s+medyczn[aey])\b/iu' => 3.0,
            '/\b(morsk[aey]\s+energetyk[aai]\s+wiatrow[aey])\b/iu' => 3.0,
            '/\b(morskie\s+farmy\s+wiatrowe\s+na\s+bałtyku)\b/iu' => 3.4,
        ];
        foreach ($patterns as $rx => $boost) {
            if (preg_match_all($rx, $raw, $m)) {
                foreach (($m[1] ?? []) as $phrase) {
                    $norm = $this->norm((string)$phrase);
                    if ($this->isGoodTopicPhrase($norm)) {
                        $out[$norm] = ($out[$norm] ?? 0.0) + $boost;
                    }
                }
            }
        }
        return $out;
    }

    private function bestFallbackPhrase(array $rawTexts): string
    {
        $blob = implode("\n", $rawTexts);
        if (preg_match('/\b(sztuczn[aey]\s+inteligencj[aai]\s+w\s+diagnostyce\s+medycznej)\b/iu', $blob, $m)) {
            return $this->norm((string)$m[1]);
        }
        if (preg_match('/\b(sztuczn[aey]\s+inteligencj[aai])\b/iu', $blob, $m)) {
            return $this->norm((string)$m[1]);
        }
        if (preg_match('/\b(diagnostyk[aai]\s+medyczn[aey])\b/iu', $blob, $m)) {
            return $this->norm((string)$m[1]);
        }
        return '';
    }

    /** @return string[] */
    private function sectionHintsFromText(string $raw): array
    {
        $raw = mb_strtolower($raw, 'UTF-8');
        $out = [];
        if (preg_match('/\b(to|jest|są uznawane|stanowi|staje się|jest przedstawian|wykorzystuj[ea]|stosowan[ea])\b/u', $raw)) $out[] = 'definition';
        if (preg_match('/\b(dan[eau]|algorytm|model|walidacj|czułość|swoistość|klinicz|tomografi|rezonans|mammografi|obraz|laboratoryjn)\b/u', $raw)) $out[] = 'technical';
        if (preg_match('/\b(wymaga|wdrażanie|odpowiedzialnoś|bezpieczeństw|nadzorem|lekarzy|lekarza|pacjenta|opieki)\b/u', $raw)) $out[] = 'practical';
        if (preg_match('/\b(moim zdaniem|z drugiej strony|niepokój|nadzieję|sceptycy)\b/u', $raw)) $out[] = 'opinion';
        if (preg_match('/\b(korzyści|zastosowań|przynosi|wspieraniu jego pracy)\b/u', $raw)) $out[] = 'background';
        return $out;
    }

    private function isGoodTopicPhrase(string $phrase): bool
    {
        if ($phrase === '' || mb_strlen($phrase, 'UTF-8') < 6) return false;
        if (preg_match('/^\d+$/u', $phrase)) return false;
        if (preg_match('/\b(fałszywie|warunkiem|znaczenie|rozwoju|uwarunkowań|skutków|jednocześnie|coraz|jednak)\b/iu', $phrase)) return false;
        $words = preg_split('/\s+/u', $phrase) ?: [];
        if (count($words) === 1) {
            // allow only strong domain terms
            return preg_match('/^(mars|bałtyk|ślęża|diagnostyka|medycyna|algorytmy?|offshore)$/iu', $phrase) === 1;
        }
        return true;
    }

    private function isUsefulKeyword(string $word): bool
    {
        if ($word === '' || mb_strlen($word, 'UTF-8') < 3) return false;
        if (preg_match('/^(fałszywie|warunkiem|jednak|coraz|takich|takiego|tym|tych|jego|jej|ich|moim|zdaniem)$/iu', $word)) return false;
        return true;
    }

    private function norm(string $text): string
    {
        $text = mb_strtolower(trim($text), 'UTF-8');
        $text = preg_replace('/[^\p{L}\p{N}\s\-]/u', ' ', $text) ?? $text;
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        return trim($text);
    }

    private function titleCase(string $text): string
    {
        $text = trim($text);
        if ($text === '') return '';
        return mb_convert_case($text, MB_CASE_TITLE, 'UTF-8');
    }
}
