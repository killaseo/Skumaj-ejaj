<?php
declare(strict_types=1);

namespace TextMixer;

final class ProfileSelector
{
    /** @var array<string,string[]> */
    private array $prototypes = [
        'place_cultural' => ['góra','szczyt','masyw','miejsce','kult','szlak','region','park','legend'],
        'infrastructure_energy' => ['energia','energetyka','inwestycja','infrastruktura','port','przesył','farmy','wiatrowe','bałtyk','offshore'],
        'medical_abstract' => ['diagnostyka','medyczna','algorytm','algorytmy','dane','kliniczne','obrazy','radiologiczne','sztuczna','inteligencja','tomografia','rezonans'],
        'mixed_science_discourse' => ['misja','atmosfera','kolonizacja','eksploracja','planeta','warunki','mars','sonda','rakieta'],
    ];

    public function __construct(private ProfileManager $profileManager, private ?VectorIndex $vectorIndex = null) {}

    /** @param array<int,array<string,mixed>> $segments */
    public function select(array $segments): Profile
    {
        $tokenWeights = [];
        $rawBlob = [];
        foreach ($segments as $seg) {
            $raw = (string)($seg['raw'] ?? '');
            if ($raw !== '') {
                $rawBlob[] = $raw;
                foreach ($this->extractTermsFromRaw($raw) as $term) {
                    $tokenWeights[$term] = ($tokenWeights[$term] ?? 0.0) + 1.0;
                }
            }
            foreach (($seg['keywords'] ?? []) as $kw) {
                $word = $this->norm((string)($kw['word'] ?? ''));
                if ($this->isUsefulToken($word)) {
                    $tokenWeights[$word] = max($tokenWeights[$word] ?? 0.0, (float)($kw['weight'] ?? 0.0));
                }
            }
            foreach (($seg['phrases'] ?? []) as $ph) {
                $phrase = $this->norm((string)($ph['phrase'] ?? ''));
                if ($phrase === '') continue;
                foreach (preg_split('/\s+/u', $phrase) ?: [] as $part) {
                    if ($this->isUsefulToken($part)) {
                        $tokenWeights[$part] = ($tokenWeights[$part] ?? 0.0) + ((float)($ph['score'] ?? 0.0) * 0.35);
                    }
                }
            }
        }

        arsort($tokenWeights);
        $topWords = array_slice(array_keys($tokenWeights), 0, 30);
        $joined = mb_strtolower(implode("\n", $rawBlob), 'UTF-8');

        $scores = [];
        foreach ($this->prototypes as $profile => $protoTerms) {
            $scores[$profile] = $this->scoreProfile($profile, $protoTerms, $topWords, $joined);
        }
        arsort($scores);
        $best = (string)(array_key_first($scores) ?? 'generic');

        if (($scores[$best] ?? 0.0) < 2.2) {
            $best = 'generic';
        }

        return $this->profileManager->load($best);
    }

    /** @param string[] $protoTerms @param string[] $topWords */
    private function scoreProfile(string $profile, array $protoTerms, array $topWords, string $joined): float
    {
        $score = 0.0;
        foreach ($protoTerms as $term) {
            if (in_array($term, $topWords, true)) {
                $score += 1.5;
            }
        }

        if ($this->vectorIndex && $topWords !== []) {
            $score += $this->vectorIndex->segmentSimilarity($topWords, $protoTerms) * 5.0;
        }

        // profile-specific raw-text cues
        if ($profile === 'medical_abstract') {
            $score += $this->regexHits($joined, [
                '/\b(sztuczn[aey]\s+inteligencj[aai]|\bai\b)\b/iu' => 2.6,
                '/\b(diagnostyk[aeyi]|medyczn[aey]|kliniczn[aey]|radiologiczn[aey])\b/iu' => 2.2,
                '/\b(tomografi[aie]|rezonans|mammografi[aie]|danych?\s+treningowych|walidacj[ai])\b/iu' => 1.8,
            ]);
        } elseif ($profile === 'infrastructure_energy') {
            $score += $this->regexHits($joined, [
                '/\b(farmy?\s+wiatrowe|energetyk[aai]\s+wiatrow[aey]|offshore)\b/iu' => 2.6,
                '/\b(bałtyk|morzu?\s+bałtyckim|portow[aey]|przesyłow[aey]|zaplecza?)\b/iu' => 2.0,
                '/\b(inwestycj[aey]|gospodark[ai]|regionach\s+nadmorskich)\b/iu' => 1.6,
            ]);
        } elseif ($profile === 'place_cultural') {
            $score += $this->regexHits($joined, [
                '/\b(gór[aey]|szczyt|masyw|szlak|park\s+krajobrazow[yia])\b/iu' => 2.2,
                '/\b(wierzeni[aey]|kultow[aey]|legend|miejscem\s+kultowym)\b/iu' => 1.8,
            ]);
        } elseif ($profile === 'mixed_science_discourse') {
            $score += $this->regexHits($joined, [
                '/\b(mars|planeta|kolonizacj[aey]|eksploracj[aey])\b/iu' => 2.4,
                '/\b(misj[ai]|sond[ay]|rakiet[ay]|orbit[aeę])\b/iu' => 1.8,
            ]);
        }

        return $score;
    }

    /** @return string[] */
    private function extractTermsFromRaw(string $raw): array
    {
        $raw = $this->norm($raw);
        $parts = preg_split('/\s+/u', $raw) ?: [];
        $out = [];
        foreach ($parts as $p) {
            if ($this->isUsefulToken($p)) {
                $out[] = $p;
            }
        }
        return $out;
    }

    private function regexHits(string $text, array $patterns): float
    {
        $sum = 0.0;
        foreach ($patterns as $rx => $weight) {
            if (preg_match($rx, $text)) {
                $sum += (float)$weight;
            }
        }
        return $sum;
    }

    private function isUsefulToken(string $word): bool
    {
        if ($word === '' || mb_strlen($word, 'UTF-8') < 3) return false;
        if (preg_match('/^\d+$/u', $word)) return false;
        static $stop = [
            'oraz','które','który','która','tego','takich','takiego','także','jednak','coraz','wraz',
            'warunkiem','fałszywie','coraz','jego','jej','ich','tym','tych','to','jest','są','dla','nad',
            'przez','jako','oraz','zatem','wobec','moim','zdaniem','strony'
        ];
        return !in_array($word, $stop, true);
    }

    private function norm(string $text): string
    {
        $text = mb_strtolower(trim($text), 'UTF-8');
        $text = preg_replace('/[^\p{L}\p{N}\s\-]/u', ' ', $text) ?? $text;
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        return trim($text);
    }
}
