<?php
declare(strict_types=1);

namespace TextMixer;

class Deduplicator
{
    private float $threshold;

    private const FINGERPRINT_WORDS = 12;

    private const STOP_WORDS = [
        'the','a','an','and','or','but','in','on','at','to','for','of','with','by','from','is','are','was','were','be','been',
        'has','have','had','that','this','it','its','as','up','out','if','not','no','so','do','did','can','will','just','also',
        'jest','oraz','ale','czy','nie','tak','jak','dla','nad','pod','przez','się','tym','tego','tegoż','który','która','które',
        'ten','ta','to','jej','jego','ich','ona','ono','oni','one','został','została','zostało','wraz','między','około','jednak',
    ];

    public function __construct(float $threshold = 0.78)
    {
        $this->threshold = $threshold;
    }

    /**
     * @param  array<int,array<string,mixed>> $segments
     * @return array{
     *     kept:         array<int,array<string,mixed>>,
     *     rejected:     array<int,array<string,mixed>>,
     *     merged_pairs: array<int,array{kept_id:string,removed_id:string,similarity:float,reason:string}>
     * }
     */
    public function deduplicate(array $segments): array
    {
        $kept = [];
        $rejected = [];
        $mergedPairs = [];

        $fpGroups = [];
        foreach ($segments as $seg) {
            $fp = $this->fingerprint((string) ($seg['raw'] ?? ''));
            $fpGroups[$fp][] = $seg;
        }

        foreach ($fpGroups as $group) {
            if (count($group) === 1) {
                $kept[] = $group[0];
                continue;
            }
            $best = $this->pickBest($group);
            foreach ($group as $seg) {
                if ($seg['segment_id'] === $best['segment_id']) {
                    continue;
                }
                $sim = $this->semanticSimilarity((string) $seg['raw'], (string) $best['raw']);
                $mergedPairs[] = [
                    'kept_id' => (string) $best['segment_id'],
                    'removed_id' => (string) $seg['segment_id'],
                    'similarity' => round($sim, 4),
                    'reason' => 'fingerprint-match',
                ];
                $rejected[] = $seg;
            }
            $kept[] = $best;
        }

        $kept = array_values($kept);
        $finalKept = [];
        foreach ($kept as $candidate) {
            $winnerIndex = null;
            $winnerSim = 0.0;
            foreach ($finalKept as $idx => $existing) {
                $sim = $this->semanticSimilarity((string) $candidate['raw'], (string) $existing['raw']);
                if ($sim >= $this->threshold && $sim > $winnerSim) {
                    $winnerIndex = $idx;
                    $winnerSim = $sim;
                }
            }

            if ($winnerIndex === null) {
                $finalKept[] = $candidate;
                continue;
            }

            $existing = $finalKept[$winnerIndex];
            if ($this->shouldReplace($candidate, $existing)) {
                $mergedPairs[] = [
                    'kept_id' => (string) $candidate['segment_id'],
                    'removed_id' => (string) $existing['segment_id'],
                    'similarity' => round($winnerSim, 4),
                    'reason' => 'semantic-near-duplicate',
                ];
                $rejected[] = $existing;
                $finalKept[$winnerIndex] = $candidate;
            } else {
                $mergedPairs[] = [
                    'kept_id' => (string) $existing['segment_id'],
                    'removed_id' => (string) $candidate['segment_id'],
                    'similarity' => round($winnerSim, 4),
                    'reason' => 'semantic-near-duplicate',
                ];
                $rejected[] = $candidate;
            }
        }

        return [
            'kept' => array_values($finalKept),
            'rejected' => $rejected,
            'merged_pairs' => $mergedPairs,
        ];
    }

    private function fingerprint(string $raw): string
    {
        $words = $this->contentWords($raw);
        sort($words);
        return implode(' ', array_slice(array_unique($words), 0, self::FINGERPRINT_WORDS));
    }

    /** @return array<int,string> */
    private function contentWords(string $raw): array
    {
        $words = preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower($raw, 'UTF-8')) ?: [];
        return array_values(array_filter($words, fn($w) => mb_strlen($w, 'UTF-8') > 2 && !in_array($w, self::STOP_WORDS, true)));
    }

    private function normalise(string $raw): string
    {
        $s = mb_strtolower($raw, 'UTF-8');
        $s = preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $s) ?? $s;
        return trim((string) preg_replace('/\s+/u', ' ', $s));
    }

    private function semanticSimilarity(string $a, string $b): float
    {
        $na = $this->normalise($a);
        $nb = $this->normalise($b);
        if ($na === '' || $nb === '') {
            return 0.0;
        }
        if ($na === $nb) {
            return 1.0;
        }

        $wa = array_fill_keys($this->contentWords($a), true);
        $wb = array_fill_keys($this->contentWords($b), true);
        $wordInter = count(array_intersect_key($wa, $wb));
        $wordUnion = count($wa) + count($wb) - $wordInter;
        $wordJaccard = $wordUnion > 0 ? $wordInter / $wordUnion : 0.0;

        $charJaccard = $this->jaccardChar($na, $nb);
        similar_text($na, $nb, $pct);
        $charPct = $pct / 100.0;

        return (0.45 * $wordJaccard) + (0.35 * $charJaccard) + (0.20 * $charPct);
    }

    private function jaccardChar(string $a, string $b): float
    {
        $biA = $this->bigrams($a);
        $biB = $this->bigrams($b);
        if (empty($biA) || empty($biB)) {
            return 0.0;
        }
        $inter = count(array_intersect_key($biA, $biB));
        $union = count($biA) + count($biB) - $inter;
        return $union > 0 ? $inter / $union : 0.0;
    }

    /** @return array<string,int> */
    private function bigrams(string $s): array
    {
        $bg = [];
        $len = mb_strlen($s, 'UTF-8');
        for ($i = 0; $i < $len - 1; $i++) {
            $k = mb_substr($s, $i, 2, 'UTF-8');
            $bg[$k] = ($bg[$k] ?? 0) + 1;
        }
        return $bg;
    }

    /** @param array<int,array<string,mixed>> $group @return array<string,mixed> */
    private function pickBest(array $group): array
    {
        usort($group, function (array $a, array $b): int {
            $aScore = (float) ($a['score'] ?? 0.0);
            $bScore = (float) ($b['score'] ?? 0.0);
            if ($aScore !== $bScore) {
                return $bScore <=> $aScore;
            }
            return mb_strlen((string) ($b['raw'] ?? ''), 'UTF-8') <=> mb_strlen((string) ($a['raw'] ?? ''), 'UTF-8');
        });
        return $group[0];
    }

    /** @param array<string,mixed> $candidate @param array<string,mixed> $existing */
    private function shouldReplace(array $candidate, array $existing): bool
    {
        $cScore = (float) ($candidate['score'] ?? 0.0);
        $eScore = (float) ($existing['score'] ?? 0.0);
        if ($cScore !== $eScore) {
            return $cScore > $eScore;
        }
        return mb_strlen((string) ($candidate['raw'] ?? ''), 'UTF-8') > mb_strlen((string) ($existing['raw'] ?? ''), 'UTF-8');
    }
}
