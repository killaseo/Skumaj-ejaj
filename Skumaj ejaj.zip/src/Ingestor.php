<?php
declare(strict_types=1);

namespace TextMixer;

/**
 * Ingestor
 * Reads all .txt files from the input directory, assigns a unique source_id
 * to each, and returns an array of TextSource data structures.
 *
 * TextSource shape:
 *   source_id  : string  (e.g. "src_01")
 *   filename   : string
 *   raw_text   : string  (original file contents)
 *   clean_text : string  (populated by Cleaner, empty here)
 */
class Ingestor
{
    private string $inputDir;

    public function __construct(string $inputDir)
    {
        $this->inputDir = rtrim($inputDir, DIRECTORY_SEPARATOR);
    }

    /** @return array<int, array<string,string>> */
    public function ingest(): array
    {
        $files = glob($this->inputDir . DIRECTORY_SEPARATOR . '*.txt');
        if ($files === false || count($files) === 0) {
            throw new \RuntimeException("No .txt files found in: {$this->inputDir}");
        }
        sort($files);

        $sources = [];
        foreach ($files as $index => $filepath) {
            $raw = file_get_contents($filepath);
            if ($raw === false) {
                throw new \RuntimeException("Cannot read file: $filepath");
            }
            $sources[] = [
                'source_id'  => sprintf('src_%02d', $index + 1),
                'filename'   => basename($filepath),
                'raw_text'   => $raw,
                'clean_text' => '',   // filled by Cleaner
            ];
        }
        return $sources;
    }
}
