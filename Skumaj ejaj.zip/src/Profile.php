<?php
declare(strict_types=1);

namespace TextMixer;

final class Profile
{
    public function __construct(private array $data) {}

    public function getName(): string
    {
        return (string)($this->data['name'] ?? 'generic');
    }

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->data[$key] ?? $default;
    }

    public function all(): array
    {
        return $this->data;
    }
}
