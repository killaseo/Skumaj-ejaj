<?php
declare(strict_types=1);

namespace TextMixer;

/**
 * ConflictDetector
 * Finds hard conflicts, soft conflicts, entity collisions, and ambiguous
 * numeric variants across segments. Never hides conflicts — every one is
 * recorded explicitly in the output.
 *
 * Conflict shape:
 *   conflict_id       : string
 *   type              : string  (hard|soft|entity_collision|numeric_variant|ambiguous)
 *   entity_or_claim   : string
 *   involved_segments : string[]
 *   description       : string
 *   severity          : string  (high|medium|low)
 */
class ConflictDetector
{
    private int $counter = 0;

    /**
     * @param  array<int,array<string,mixed>>    $segments
     * @param  array<string,array<string,mixed>> $entityRegistry
     * @return array<int,array<string,mixed>>
     */
    public function detect(array $segments, array $entityRegistry): array
    {
        $conflicts = [];
        $conflicts = array_merge($conflicts, $this->detectNumericVariants($segments));
        $conflicts = array_merge($conflicts, $this->detectDateConflicts($segments));
        $conflicts = array_merge($conflicts, $this->detectEntityCollisions($segments, $entityRegistry));
        $conflicts = array_merge($conflicts, $this->detectContradictoryRelations($segments));
        return $conflicts;
    }

    /** Detect same subject with different numeric values (altitude, population, area) */
    private function detectNumericVariants(array $segments): array
    {
        $conflicts = [];
        // Patterns: [label, regex]
        $numericPatterns = [
            ['altitude',   '/\b(\d{3,4})\s*meters?\b/i'],
            ['population', '/\bpopulation\s+(?:of\s+)?(?:approximately\s+)?(\d[\d,]+)/i'],
            ['area',       '/\b(\d[\d,]+)\s*hectares?\b/i'],
            ['year',       '/\b(1[0-9]{3})\b/'],
        ];

        foreach ($numericPatterns as [$label, $pattern]) {
            $found = []; // value => [segment_ids]
            foreach ($segments as $seg) {
                if (preg_match_all($pattern, $seg['raw'], $matches)) {
                    foreach ($matches[1] as $val) {
                        $val = str_replace(',', '', $val);
                        $found[$val][] = $seg['segment_id'];
                    }
                }
            }
            if (count($found) > 1) {
                $allSegs = array_unique(array_merge(...array_values($found)));
                $valueList = implode(' vs ', array_keys($found));
                $severity = ($label === 'altitude') ? 'high' : 'medium';
                $this->counter++;
                $conflicts[] = [
                    'conflict_id'       => sprintf('cfl_%04d', $this->counter),
                    'type'              => 'numeric_variant',
                    'entity_or_claim'   => $label,
                    'involved_segments' => $allSegs,
                    'description'       => "Different $label values found: $valueList",
                    'severity'          => $severity,
                ];
            }
        }
        return $conflicts;
    }

    /** Detect conflicting century/period claims for the same topic */
    private function detectDateConflicts(array $segments): array
    {
        $conflicts = [];
        $cultPatterns = [
            '/\b([6-9]th|[1-9][0-9]th|[6-9]th)\s+century\b/i',
            '/\b(Bronze Age|Iron Age)\b/i',
        ];
        $found = [];
        foreach ($segments as $seg) {
            foreach ($cultPatterns as $p) {
                if (preg_match_all($p, $seg['raw'], $m)) {
                    foreach ($m[0] as $val) {
                        $found[strtolower($val)][] = $seg['segment_id'];
                    }
                }
            }
        }
        // Collect century numbers and check for spread > 2
        $centuries = [];
        foreach (array_keys($found) as $val) {
            if (preg_match('/(\d+)th/', $val, $m)) {
                $centuries[(int)$m[1]] = $val;
            }
        }
        if (count($centuries) > 1) {
            ksort($centuries);
            $spread = max(array_keys($centuries)) - min(array_keys($centuries));
            if ($spread > 1) {
                $allSegs = array_unique(array_merge(...array_values($found)));
                $this->counter++;
                $conflicts[] = [
                    'conflict_id'       => sprintf('cfl_%04d', $this->counter),
                    'type'              => 'soft',
                    'entity_or_claim'   => 'cult_period_start',
                    'involved_segments' => $allSegs,
                    'description'       => 'Sources disagree on start of cult activity: ' . implode(', ', array_values($centuries)),
                    'severity'          => 'medium',
                ];
            }
        }
        return $conflicts;
    }

    /** Detect same entity mentioned with conflicting attributes across sources */
    private function detectEntityCollisions(array $segments, array $entityRegistry): array
    {
        $conflicts = [];
        // For each entity that appears in multiple sources, check if
        // its associated numeric facts differ
        foreach ($entityRegistry as $entity) {
            if (count($entity['source_mentions']) < 2) continue;
            // Find segments for this entity across sources
            $bySource = [];
            foreach ($segments as $seg) {
                if (in_array($entity['entity_id'], $seg['entities'], true)) {
                    $bySource[$seg['source_id']][] = $seg['segment_id'];
                }
            }
            // Entity appears in 2+ sources — flag as potential collision point
            // (actual value comparison done in numeric pass; this flags structural collision)
            if (count($bySource) >= 2 && count($entity['aliases']) > 0) {
                $this->counter++;
                $allSegs = array_unique(array_merge(...array_values($bySource)));
                $conflicts[] = [
                    'conflict_id'       => sprintf('cfl_%04d', $this->counter),
                    'type'              => 'entity_collision',
                    'entity_or_claim'   => $entity['name'],
                    'involved_segments' => $allSegs,
                    'description'       => sprintf(
                        'Entity "%s" appears under %d aliases across %d sources: %s',
                        $entity['name'],
                        count($entity['aliases']),
                        count($bySource),
                        implode(', ', $entity['aliases'])
                    ),
                    'severity'          => 'low',
                ];
            }
        }
        return $conflicts;
    }

    /** Detect contradictory relations: same subject+predicate but different objects */
    private function detectContradictoryRelations(array $segments): array
    {
        $conflicts = [];
        $relMap = []; // "subject|predicate" => [object => [seg_ids]]
        foreach ($segments as $seg) {
            foreach ($seg['relations'] as $rel) {
                $key = strtolower($rel['subject'] . '|' . $rel['predicate']);
                $obj = strtolower(trim($rel['object']));
                $relMap[$key][$obj][] = $seg['segment_id'];
            }
        }
        foreach ($relMap as $key => $objects) {
            if (count($objects) > 1) {
                [$subject, $predicate] = explode('|', $key, 2);
                $allSegs = array_unique(array_merge(...array_values($objects)));
                $this->counter++;
                $conflicts[] = [
                    'conflict_id'       => sprintf('cfl_%04d', $this->counter),
                    'type'              => 'hard',
                    'entity_or_claim'   => "$subject $predicate",
                    'involved_segments' => $allSegs,
                    'description'       => sprintf(
                        'Contradictory relation: "%s %s" has objects: %s',
                        $subject, $predicate, implode(' | ', array_keys($objects))
                    ),
                    'severity'          => 'high',
                ];
            }
        }
        return $conflicts;
    }
}
