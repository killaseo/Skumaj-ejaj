<?php
return [
    'name' => 'mixed_science_discourse',
    'topic_entity_mode' => 'mixed_axis',
    'preferred_topic_patterns' => ['mars','eksploracja marsa','kolonizacja marsa','atmosfera marsa'],
    'topic_phrase_patterns' => ['/mars/ui','/eksploracj[aey]\s+marsa/ui','/kolonizacj[aey]\s+marsa/ui','/atmosfer[aay]\s+marsa/ui'],
    'preferred_relations' => ['jest','ma','prowadzi do','umożliwia','utrudnia'],
    'lead_preference' => 'neutral_axis_first',
    'preferred_sections' => ['news','technical','opinion','background'],
    'blocked_lead_openings' => ['Czy','Mają rację','Poza tym'],
    'allow_sectioned_article' => true,
    'allow_dominant_axis_article' => true,
    'allow_unified_article' => false,
    'entity_phrase_first' => true,
    'concept_phrase_first' => true,
    'relation_bias' => ['jest'=>1.05,'ma'=>1.05,'prowadzi do'=>1.2,'umożliwia'=>1.15,'utrudnia'=>1.2],
];
