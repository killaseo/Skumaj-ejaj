<?php
return [
    'name' => 'medical_abstract',
    'topic_entity_mode' => 'concept_phrase_first',
    'preferred_topic_patterns' => ['sztuczna inteligencja','diagnostyka medyczna','uczenie maszynowe','dane kliniczne','obrazy radiologiczne'],
    'topic_phrase_patterns' => ['/sztuczn[aey]\s+inteligencj[aai]/ui','/diagnostyk[aai]\s+medyczn[aey]/ui','/uczeni[eau]\s+maszynow[eau]/ui','/dan[eau]\s+kliniczn[eau]/ui','/obraz[yaó]\s+radiologiczn[eau]/ui'],
    'preferred_relations' => ['wykorzystuje','wspomaga','analizuje','zależy od','wymaga'],
    'lead_preference' => 'concept_definition_first',
    'preferred_sections' => ['definition','technical','practical','opinion','background'],
    'blocked_lead_openings' => ['Warunkiem jest','Mają rację','Z drugiej strony','Oczywiście'],
    'entity_phrase_first' => true,
    'concept_phrase_first' => true,
    'relation_bias' => ['wykorzystuje'=>1.3,'wspomaga'=>1.3,'analizuje'=>1.25,'zależy od'=>1.2,'wymaga'=>1.15],
];
