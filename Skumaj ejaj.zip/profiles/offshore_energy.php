<?php
return [
    'name' => 'offshore_energy',
    'topic_entity_mode' => 'phrase_first',
    'preferred_topic_patterns' => ['morskie farmy wiatrowe','morska energetyka wiatrowa','energetyka offshore','farmy wiatrowe na bałtyku'],
    'topic_phrase_patterns' => ['/morsk[aie]\s+farmy?\s+wiatrowe\s+na\s+bałtyku/ui','/morsk[aie]\s+energetyk[aai]\s+wiatrow[aey]/ui','/energetyk[aai]\s+offshore/ui'],
    'preferred_relations' => ['jest elementem','sprzyja','wymaga','przynosi korzyści','obejmuje'],
    'lead_preference' => 'definition_first',
    'preferred_sections' => ['definition','technical','practical','background'],
    'blocked_lead_openings' => ['Konieczne jest','Wynika to','Ich przewagą jest','Z tymi','W szerszej perspektywie'],
    'entity_phrase_first' => true,
    'concept_phrase_first' => false,
    'relation_bias' => ['jest elementem'=>1.3,'sprzyja'=>1.2,'wymaga'=>1.25,'przynosi korzyści'=>1.3],
];
