<?php
return [
    'name' => 'generic',
    'topic_entity_mode' => 'auto',
    'preferred_topic_patterns' => [],
    'topic_phrase_patterns' => [],
    'preferred_relations' => [],
    'lead_preference' => 'definition_first',
    'preferred_sections' => ['definition','technical','practical','background','opinion'],
    'blocked_lead_openings' => ['Konieczne jest','Wynika to','Ich przewagą jest','Z tymi','W szerszej perspektywie','Mają rację','Warunkiem jest'],
    'short_fragment_min_chars' => 18,
    'allow_sectioned_article' => true,
    'allow_dominant_axis_article' => true,
    'allow_unified_article' => true,
    'entity_phrase_first' => false,
    'concept_phrase_first' => false,
    'relation_bias' => [],
];
