<?php
return [
    'name' => 'place_cultural',
    'topic_entity_mode' => 'place_object_first',
    'preferred_topic_patterns' => ['góra','szczyt','masyw','miejsce kultowe','park krajobrazowy'],
    'topic_phrase_patterns' => ['/gór[aey]\s+[\p{Lu}][\p{L}\-]+/u','/masyw\s+[\p{Lu}][\p{L}\-]+/u','/park\s+krajobrazowy/ui'],
    'preferred_relations' => ['leży na','znajduje się w','wiąże się z','jest'],
    'lead_preference' => 'place_definition_first',
    'preferred_sections' => ['definition','background','practical','technical'],
    'blocked_lead_openings' => ['Z tym miejscem','Od dawna','W pobliżu'],
    'entity_phrase_first' => true,
    'concept_phrase_first' => false,
    'relation_bias' => ['leży na'=>1.3,'znajduje się w'=>1.25,'wiąże się z'=>1.2,'jest'=>1.1],
];
