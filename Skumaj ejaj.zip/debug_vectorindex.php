<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

spl_autoload_register(function (string $class): void {
    $prefix = 'TextMixer\\';
    if (str_starts_with($class, $prefix)) {
        $file = __DIR__ . '/src/' . substr($class, strlen($prefix)) . '.php';
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }
    throw new RuntimeException("Cannot autoload class: $class");
});

echo "<pre>";

try {
    $dbPath = realpath(__DIR__ . '/../../vectors/vectors_clean.sqlite');
    echo "DB: " . $dbPath . "\n";

    $vi = new TextMixer\VectorIndex($dbPath);
    echo "VectorIndex created\n";

    echo "isAvailable: ";
    var_dump($vi->isAvailable());

} catch (Throwable $e) {
    echo "ERROR:\n";
    echo $e->getMessage() . "\n";
    echo $e->getFile() . ":" . $e->getLine() . "\n";
}