<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

echo "<pre>";

$dbPath = __DIR__ . '/../../vectors/vectors_clean.sqlite';
$real = realpath($dbPath);

echo "__DIR__: " . __DIR__ . "\n";
echo "DB PATH: $dbPath\n";
echo "REALPATH: " . ($real ?: 'false') . "\n";
echo "FILE EXISTS: " . (is_file($dbPath) ? 'yes' : 'no') . "\n\n";

echo "PDO sqlite loaded: " . (extension_loaded('pdo_sqlite') ? 'yes' : 'no') . "\n";
echo "SQLite3 loaded: " . (extension_loaded('sqlite3') ? 'yes' : 'no') . "\n\n";

try {
    $pdo = new PDO('sqlite:' . $dbPath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "PDO CONNECT: OK\n";

    $tables = $pdo->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);
    echo "TABLES:\n";
    print_r($tables);

    $row = $pdo->query("SELECT term, term_freq, doc_freq, context_count, quality_score FROM vectors LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    echo "SAMPLE ROW:\n";
    print_r($row);

} catch (Throwable $e) {
    echo "ERROR:\n";
    echo $e->getMessage() . "\n";
    echo $e->getFile() . ":" . $e->getLine() . "\n";
}