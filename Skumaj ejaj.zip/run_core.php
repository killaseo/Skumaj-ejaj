<?php
declare(strict_types=1);

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

spl_autoload_register(function (string $class): void {
    $prefix = 'TextMixer\\';
    if (str_starts_with($class, $prefix)) {
        $file = __DIR__ . '/src/' . substr($class, strlen($prefix)) . '.php';
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }
    throw new \RuntimeException("Cannot autoload class: $class");
});

use TextMixer\Engine;
use TextMixer\Ingestor;
use TextMixer\Cleaner;
use TextMixer\Segmenter;
use TextMixer\LexicalScorer;
use TextMixer\EntityExtractor;
use TextMixer\AliasResolver;
use TextMixer\RelationMapper;
use TextMixer\Clusterer;
use TextMixer\SimilarityEngine;
use TextMixer\ConflictDetector;
use TextMixer\CoreExtractor;
use TextMixer\Composer;
use TextMixer\JsonWriter;
use TextMixer\ProfileManager;
use TextMixer\ProfileSelector;
use TextMixer\TopicContextBuilder;
use TextMixer\VectorIndex;
use TextMixer\Deduplicator;
use TextMixer\DiscourseClassifier;
use TextMixer\CompositionPlanner;

$opts = getopt('', ['input::', 'output::', 'profile::', 'vectors::']);

$inputDir    = $opts['input']   ?? __DIR__ . '/input';
$outputDir   = $opts['output']  ?? __DIR__ . '/output';
$profileName = $opts['profile'] ?? 'auto';

if (!empty($opts['vectors'])) {
    $r = realpath($opts['vectors']);
    $vectorsPath = ($r && is_file($r)) ? $r : null;
} else {
    $vectorCandidates = [
        __DIR__ . '/../../vectors/vectors_clean.sqlite',
        __DIR__ . '/../vectors/vectors_clean.sqlite',
        __DIR__ . '/vectors/vectors_clean.sqlite',
    ];

    $vectorsPath = null;
    foreach ($vectorCandidates as $c) {
        $r = realpath($c);
        if ($r && is_file($r)) {
            $vectorsPath = $r;
            break;
        }
    }
}

if (!$vectorsPath) {
    http_response_code(500);
    exit('Błąd: nie znaleziono vectors_clean.sqlite. Sprawdź ścieżkę w run_core.php');
}

$profileManager = new ProfileManager(__DIR__ . '/profiles');
$vectorIndex = new VectorIndex($vectorsPath);
$profileSelector = new ProfileSelector($profileManager, $vectorIndex->isAvailable() ? $vectorIndex : null);
$topicContextBuilder = new TopicContextBuilder($vectorIndex->isAvailable() ? $vectorIndex : null);
$initialProfile = $profileName === 'auto'
    ? $profileManager->load('generic')
    : $profileManager->load($profileName);

echo "========================================\n";
echo "  Text Mixer Core Engine v2\n";
echo "========================================\n";
echo "Input   : $inputDir\n";
echo "Output  : $outputDir\n";
echo "Profile : $profileName\n";
echo "Vectors : $vectorsPath\n";
echo "----------------------------------------\n";

try {
    $ingestor         = new Ingestor($inputDir);
    $cleaner          = new Cleaner();
    $segmenter        = new Segmenter();
    $lexicalScorer    = new LexicalScorer();
    $entityExtractor  = new EntityExtractor($initialProfile);
    $aliasResolver    = new AliasResolver();
    $relationMapper   = new RelationMapper($initialProfile);
    $clusterer        = new Clusterer(0.12);
    $conflictDetector = new ConflictDetector();
    $similarityEngine = new SimilarityEngine();
    $coreExtractor    = new CoreExtractor($similarityEngine);
    $discourse        = new DiscourseClassifier($initialProfile);
    $planner          = new CompositionPlanner($initialProfile);
    $composer         = new Composer(new Deduplicator(), $initialProfile);
    $jsonWriter       = new JsonWriter($outputDir);

    $engine = new Engine(
        $ingestor,
        $cleaner,
        $segmenter,
        $lexicalScorer,
        $entityExtractor,
        $aliasResolver,
        $relationMapper,
        $clusterer,
        $conflictDetector,
        $coreExtractor,
        $composer,
        $jsonWriter,
        $profileSelector,
        $topicContextBuilder,
        $profileName === 'auto' ? null : $initialProfile,
        $discourse,
        $planner
    );

    $engine->run();

} catch (\Throwable $e) {
    echo "\n[ERROR] " . $e->getMessage() . "\n";
    echo "  File : " . $e->getFile() . ":" . $e->getLine() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}

echo "========================================\n";
exit(0);